/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package infinite;

/**
 *
 * @author Michele
 */
public class Prova {
    
  int a = 0, b = 0;
  public Prova(){}
  public Prova(int a ,int b){
   this.a = a;
   this.b = b;
  }
  public int getA (){
    return a;
  }
  public int getB (){
    return b;
  }
  public String string(){
    return "Stringa";
  }
 // public Prova 
}
