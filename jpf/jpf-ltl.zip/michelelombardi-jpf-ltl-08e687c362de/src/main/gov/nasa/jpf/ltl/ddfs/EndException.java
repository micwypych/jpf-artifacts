/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.nasa.jpf.ltl.ddfs;

/**
 *
 * @author Michele Lombardi
 */
  public class EndException extends Exception {

    EndException(String message) {
      super(message);
    }
  }
