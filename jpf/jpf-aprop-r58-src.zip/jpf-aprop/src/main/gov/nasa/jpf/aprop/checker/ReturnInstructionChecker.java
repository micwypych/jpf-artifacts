package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.ContractViolationFacade;
import gov.nasa.jpf.aprop.checker.GetInstructionChecker.GetViolationAttribute;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.ReturnInstruction;

/**
 * Checker for ReturnInstruction. 
 * 
 * @see gov.nasa.jpf.jvm.bytecode.ReturnInstruction
 */
public class ReturnInstructionChecker implements VMChecker {

	@Override
	public void check(JVM vm) {
		ReturnInstruction returnInstruction = (ReturnInstruction) vm.getLastInstruction();
		StackFrame sf = returnInstruction.getReturnFrame();
		GetViolationAttribute violationAttr = sf.getLocalAttr(0, GetViolationAttribute.class);
		if (violationAttr != null) {
			if (hasOperand(sf, violationAttr.getObjectRef()) && 
					(violationAttr.getConfinedFieldInfo().value()
							|| (violationAttr.getConfinedFieldInfo().isSelf() && !violationAttr.getConfinedFieldInfo().isConfinedContext(sf)))) {
				ContractViolationFacade.throwConfinedFieldViolation(ThreadInfo.getCurrentThread(), 
						violationAttr.getInstruction(), sf.getMethodInfo());
			}
		}
	}

	private boolean hasOperand(StackFrame sf, int operand) {
		for (int i : sf.getSlots()) { 
			if (i == operand)
				return true;
		}
		return false;
	}
}