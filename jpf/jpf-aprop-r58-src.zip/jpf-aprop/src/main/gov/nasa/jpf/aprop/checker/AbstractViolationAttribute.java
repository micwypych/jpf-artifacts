package gov.nasa.jpf.aprop.checker;

/**
 * Attribute with information necessary for violation check. 
 */
public class AbstractViolationAttribute {

	private int objectRef;

	protected AbstractViolationAttribute(int objectRef) {
		super();
		this.objectRef = objectRef;
	}

	public int getObjectRef() {
		return objectRef;
	}
	
	protected void setObjectRef(int objectRef) {
		this.objectRef = objectRef;
	}
}
