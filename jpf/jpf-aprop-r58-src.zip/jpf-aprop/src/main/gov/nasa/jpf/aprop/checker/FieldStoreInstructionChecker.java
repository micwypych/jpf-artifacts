package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.ContractViolationFacade;
import gov.nasa.jpf.aprop.region.ConfinedFieldInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfoContainer;
import gov.nasa.jpf.aprop.region.SelfConfinedFieldInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.FieldInstruction;

import java.util.Iterator;

/**
 * Parent class for static/instance field store instructions. 
 */
public abstract class FieldStoreInstructionChecker implements VMChecker {

	protected abstract <T extends FieldInstruction> int  getObjectRef(T fieldInstruction);
	
	protected abstract <T extends FieldInstruction> int getThis(T fieldInstruction);
	
	@Override
	public void check(JVM vm) {
		FieldInstruction fieldInstruction = (FieldInstruction) vm.getLastInstruction(); 
		ConfinedInfo confinedInfo = 
			ConfinedInfoContainer.instance().field(fieldInstruction.getFieldInfo());
		if (!confinedInfo.isEmpty() && confinedInfo.isFieldConfined() && ((ConfinedFieldInfo) confinedInfo).reference()) {
			ThreadInfo threadInfo = ThreadInfo.getCurrentThread();
			int objectRef = getObjectRef(fieldInstruction);
			Iterator<StackFrame> sfIterator = threadInfo.iterator();
			if (confinedInfo.isFieldConfined() && ((ConfinedFieldInfo)confinedInfo).isSelf())
				((SelfConfinedFieldInfo) confinedInfo).setOwnerReference(getThis(fieldInstruction));
			while (sfIterator.hasNext()) {
				StackFrame sf = sfIterator.next();
				if (hasOperand(sf, objectRef)) {
					if (!confinedInfo.isConfinedContext(sf)) {
						ContractViolationFacade.throwConfinedFieldViolation(threadInfo, fieldInstruction, sf.getMethodInfo());
					}
				} else {
					break;
				}
			}
		}
	}	

	private boolean hasOperand(StackFrame sf, int operand) {
		for (int i : sf.getSlots()) { 
			if (i == operand)
				return true;
		}
		return false;
	}
}