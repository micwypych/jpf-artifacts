package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.aprop.region.util.ClassInfoComparator;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.FieldInfo;
import gov.nasa.jpf.jvm.InfoObject;
import gov.nasa.jpf.jvm.MethodInfo;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;


/**
 * Singleton holding data about @Confined language constructs. 
 */
public class ConfinedInfoContainer {

	/**
	 * Map of confined methods.
	 */
	private Map<MethodInfo, ConfinedInfo> confinedMethods;
	
	/**
	 * Map of confined fields.
	 */
	private Map<FieldInfo, ConfinedInfo> confinedFields;
	
	/**
	 * Map of confined classes.
	 */
	private Map<ClassInfo, ConfinedInfo> confinedClasses;

	/**
	 * Factory creating objects with ConfinedInfo.
	 */
	private ConfinedInfoFactory confinedInfoFactory;
	
	private volatile static ConfinedInfoContainer instance;

	private ConfinedInfoContainer() {
		confinedClasses = new TreeMap<ClassInfo, ConfinedInfo>(new ClassInfoComparator());
		confinedFields = new HashMap<FieldInfo, ConfinedInfo>();
		confinedMethods = new HashMap<MethodInfo, ConfinedInfo>();	
		confinedInfoFactory = new ConfinedInfoFactory();
	}
	
	public static synchronized ConfinedInfoContainer instance() {
		if (instance == null) {
			synchronized(ConfinedInfoContainer.class) {
				if (instance == null)
					instance = new ConfinedInfoContainer();
			}
		}
		return instance;
	}
	
	/**
	 * Checks if the class is confined or contains any confined methods
	 * or fields.
	 * 
	 * @param ci
	 */
	public void classLoaded(ClassInfo ci) {
		ConfinedInfo typeConfinement = confinedInfoFactory.typeInfo(ci);
		if (!typeConfinement.isEmpty()) {
			confinedClasses.put(ci, typeConfinement);
		}
		confinedFields.putAll(confinementMap(ci.getDeclaredInstanceFields(), typeConfinement));
		confinedFields.putAll(confinementMap(ci.getDeclaredStaticFields(), typeConfinement));
		confinedMethods.putAll(confinementMap(ci.getDeclaredMethodInfos(), typeConfinement));
	}
	
	private <T extends InfoObject> Map<T, ConfinedInfo> confinementMap(
			T[] args, ConfinedInfo containerConfinement) {
		Map<T, ConfinedInfo> result = new HashMap<T, ConfinedInfo>();
		for (T i : args) {
			ConfinedInfo elementConfinedInfo =
				confinedInfoFactory.memberInfo(i, containerConfinement);
			if (!elementConfinedInfo.isEmpty())
				result.put(i, elementConfinedInfo);
		}
		return result;
	}

	public ConfinedInfo field(FieldInfo fieldInfo) {
		ConfinedInfo ci = confinedFields.get(fieldInfo);
		if (ci != null)
			return ci;
		else
			return DefaultConfinedInfo.emptyConfinedInfo();
	}
	
	public ConfinedInfo method(MethodInfo methodInfo) {
		ConfinedInfo ci = confinedMethods.get(methodInfo);
		if (ci != null)
			return ci;
		else
			return DefaultConfinedInfo.emptyConfinedInfo();
	}
	
	public ConfinedInfo forClass(ClassInfo classInfo) {
		ConfinedInfo ci = confinedClasses.get(classInfo);
		if (ci != null)
			return ci;
		else
			return DefaultConfinedInfo.emptyConfinedInfo();
	}
}
