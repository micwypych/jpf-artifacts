//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

/**
 * Message queue for DynamicRegionListener.
 * 
 * @see gov.nasa.jpf.region.listener.DynamicRegionListener
 */
public class DynamicRegionMessageQueue implements Iterable<DynamicRegionMessage<?>> {

	private static DynamicRegionMessageQueue instance;
	
	private Queue<DynamicRegionMessage<?>> messages;
	
	public static DynamicRegionMessageQueue instance() {
		if (instance == null) {
			instance = new DynamicRegionMessageQueue();
		}
		return instance;
	}
	
	private DynamicRegionMessageQueue() {
		this.messages = new LinkedList<DynamicRegionMessage<?>>();
	}

	/**
	 * Receives dynamic region message.
	 * 
	 * @param dynamicRegionMessage
	 */
	public static void receiveMessage(DynamicRegionMessage<?> dynamicRegionMessage) {
		instance().messages.add(dynamicRegionMessage);
	}
	
	/**
	 * Returns size of the queue.
	 * @return
	 */
	public static int queueSize() {
		return instance().messages.size();
	}

	@Override
	public Iterator<DynamicRegionMessage<?>> iterator() {
		return new Iterator<DynamicRegionMessage<?>>() {
			
			private Iterator<DynamicRegionMessage<?>> iterator = messages.iterator();
			
			@Override
			public void remove() {
				throw new UnsupportedOperationException("Can not remove messages from MQ.");
			}
			
			@Override
			public DynamicRegionMessage<?> next() {
				if (hasNext()) {
					return iterator.next();
				} else {
					throw new NoSuchElementException();
				}
			}
			
			@Override
			public boolean hasNext() {
				return iterator.hasNext();
			}
		};
	}

	public static void clearMQ() {
		instance().messages.clear();
	}
}
