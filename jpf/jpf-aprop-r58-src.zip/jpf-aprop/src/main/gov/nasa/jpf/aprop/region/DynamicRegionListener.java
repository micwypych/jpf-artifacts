//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.MethodInfo;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.Instruction;
import gov.nasa.jpf.jvm.bytecode.InvokeInstruction;
import gov.nasa.jpf.jvm.bytecode.ReturnInstruction;

import java.util.Iterator;

/**
 * Listener managing dynamic regions. 
 * 
 * DynamicRegionListener executes instructions from DynamicRegionMessageQueue. 
 * 
 * @see DynamicRegionForceExitMessage
 * @see DynamicRegionEnterMessage
 * @see DynamicRegionMessageQueue
 *
 */
public class DynamicRegionListener extends ListenerAdapter {
	
	public DynamicRegionListener() {
		super();
	}

	@Override
	public void instructionExecuted(JVM vm) {
		/*
		 * Handle all the messages from message queue.
		 */
		Instruction lastInstruction = vm.getLastInstruction();
		for (DynamicRegionMessage<?> msg : DynamicRegionMessageQueue.instance()) {
			msg.execute(getPreviousMethodInfo(ThreadInfo.getCurrentThread()));
		}
		DynamicRegionMessageQueue.clearMQ();

		
		if (lastInstruction instanceof InvokeInstruction) {
			/*
			 * if invoking method is in dynamic region than dynamic region 
			 * is extended to invoked method.
			 */
			InvokeInstruction invokeInstr = (InvokeInstruction) lastInstruction;
			MethodInfo invokedMethodInfo = invokeInstr.getInvokedMethod();
			MethodInfo invokingMethodInfo = invokeInstr.getMethodInfo();
			extendDynamicRegion(invokingMethodInfo, invokedMethodInfo);
		} else if (lastInstruction instanceof ReturnInstruction
				&& RegionTreeContainer.getInstance().isMethodInDynamicRegion(lastInstruction.getMethodInfo())) {
			RegionTreeContainer.getInstance().exitRegion(lastInstruction.getMethodInfo());
		}
	}

	private void extendDynamicRegion(MethodInfo invokingMethodInfo,
			MethodInfo invokedMethodInfo) {
		if (RegionTreeContainer.getInstance().isMethodInDynamicRegion(invokingMethodInfo)) {
			RegionTreeContainer.getInstance().transitDynamicRegion(invokingMethodInfo, invokedMethodInfo);
		}
		
	}	
	
	private MethodInfo getPreviousMethodInfo(ThreadInfo ti) {			
		Iterator<StackFrame> stack = ti.iterator();
		int stackCounter = 0;
		while (stack.hasNext()) {
			StackFrame frame = stack.next();
			if (stackCounter++ == 1)				
				return frame.getMethodInfo();
		}
		throw new RuntimeException("Invoking method not found.");
	}
}
