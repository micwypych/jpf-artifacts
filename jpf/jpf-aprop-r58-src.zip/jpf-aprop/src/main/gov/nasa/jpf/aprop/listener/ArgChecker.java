//
// Copyright (C) 2009 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.aprop.listener;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.JPF;
import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.jvm.AnnotationInfo;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.MethodInfo;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.Instruction;
import gov.nasa.jpf.jvm.bytecode.InvokeInstruction;
import gov.nasa.jpf.jvm.bytecode.NEW;
import gov.nasa.jpf.util.MethodSpec;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

/**
 * a listener that checks for calls with reference arguments that are not
 * allowed to be passed into specified methods
 *
 * this is mostly an example for a class of scope based, instance specific
 * properties
 */
public class ArgChecker extends ListenerAdapter {

  protected static Logger log = JPF.getLogger("gov.nasa.jpf.aprop");

  static final String NO_ARG = "gov.nasa.jpf.annotation.NoArg";


  /**
   * which MethodSpecs have to be checked
   */
  static class Attr {
    LinkedList<MethodSpec> methodSpecs = new LinkedList<MethodSpec>();

    public void add (MethodSpec ms){
      methodSpecs.add(ms);
    }
    public void addAll (List<MethodSpec> l){
      methodSpecs.addAll(l);
    }
    public List<MethodSpec> getMethodSpecs(){
      return methodSpecs;
    }
  }

  // the types we automatically attach attributes to
  // this is a flattened structure, i.e. we collect all our superclass/interface Attrs
  HashMap<ClassInfo,Attr> noArgTypes = new HashMap<ClassInfo,Attr>();


  public void instructionExecuted(JVM vm){
    Instruction insn = vm.getLastInstruction();
    ThreadInfo ti = vm.getLastThreadInfo();

    // attach attributes to instances of annotated types
    if (insn instanceof NEW && insn.isCompleted(ti)){
      int objRef = ti.peek();
      ElementInfo ei = ti.getElementInfo(objRef);
      Attr a = noArgTypes.get(ei.getClassInfo());
      if (a != null){
        // in apps with little data flow, it would be more efficient to set this
        // as an operand attribute, but we want to demonstrate how type based
        // instance attributes can be handled
        ei.setObjectAttrNoClone(a);
      }
    }
  }


  public void executeInstruction (JVM vm){
    Instruction insn = vm.getLastInstruction();
    ThreadInfo ti = vm.getLastThreadInfo();

    // check if this is a forbidden call
    if (insn instanceof InvokeInstruction){
      InvokeInstruction call = (InvokeInstruction)insn;

      if (call.hasAttrRefArgument(ti, Attr.class)){ // check first if its worth the hassle
        MethodInfo mi = call.getInvokedMethod();
        Object[] args = call.getArgumentValues(ti);

        for (int i=0; i<args.length; i++){
          Object arg = args[i];
          if (arg != null && arg instanceof ElementInfo){
            Attr attr = ((ElementInfo)arg).getObjectAttr(Attr.class);
            if (attr != null){
              for (MethodSpec mspec : attr.getMethodSpecs()) {
                if (mspec.matches(mi)) {
                  if (mspec.isMarkedArg(i)) {
                    Instruction nextPc = ti.createAndThrowException("java.lang.AssertionError",
                            "call of " + mi.getFullName() + " with argument: " + arg + 
                            "violates @NoArg(\"" + mspec.getSource()+'"');
                    ti.setNextPC(nextPc);
                    return;
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // factored out so that we can easily introduce specialized versions
  protected Attr getAttr (ClassInfo ci){
    AnnotationInfo ai = ci.getAnnotation(NO_ARG);
    if ( ai != null){
      String[] specs = ai.getValueAsStringArray();
      Attr a = new Attr();
      for (String s : specs){
        MethodSpec ms = MethodSpec.createMethodSpec(s);
        if (ms != null){
          a.add(ms);
          return a;

        } else {
          log.warning("illegal @NoArg method spec ignored: " + s);
        }
      }
    }

    return null;
  }

  public void classLoaded (JVM vm){
    ClassInfo ci = vm.getLastClassInfo();

    // check if we have an annotation ourself
    Attr a = getAttr(ci);
    if (a != null){
      noArgTypes.put(ci,a);
    }

    // check if our superclass has one
    Attr sa = noArgTypes.get(ci.getSuperClass());
    if (sa != null){
      if (a == null){
        noArgTypes.put(ci,sa);
      } else {
        a.addAll(sa.getMethodSpecs()); // it's already added
      }
    }

    // same for our interfaces
    for (ClassInfo ici : ci.getInterfaceClassInfos()){
      Attr ia = noArgTypes.get(ici);
      if (ia != null){
        if (a == null) {
          noArgTypes.put(ci, ia);
        } else {
          a.addAll(ia.getMethodSpecs()); // it's already added
        }
      }
    }
  }

  // <2do> would have to deal with OverrideNoArg here

}
