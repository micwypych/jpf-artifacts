package gov.nasa.jpf.aprop.listener;

import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.annotation.InstanceRegion;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.Instruction;
import gov.nasa.jpf.jvm.bytecode.NEW;
import gov.nasa.jpf.jvm.bytecode.PUTFIELD;
import gov.nasa.jpf.jvm.bytecode.PUTSTATIC;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Listen to violations of @InstanceRegion. 
 *
 */
public class InstanceRegionChecker extends ListenerAdapter {

//	private Map<Integer, Set<InstanceRegionAccessInfo>> instanceRegions;
	private Map<Integer, Integer> instanceRegions;
	
	/*private static class InstanceRegionAccessInfo {
		private ClassInfo accessorClassInfo;
		private int accessingReference;
		public InstanceRegionAccessInfo(ClassInfo accessorClassInfo,
				int accessingReference) {
			this.accessorClassInfo = accessorClassInfo;
			this.accessingReference = accessingReference;
		}
		public ClassInfo getAccessorClassInfo() {
			return accessorClassInfo;
		}
		public int getAccessingReference() {
			return accessingReference;
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime
					* result
					+ ((accessorClassInfo == null) ? 0 : accessorClassInfo
							.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			InstanceRegionAccessInfo other = (InstanceRegionAccessInfo) obj;
			if (accessorClassInfo == null) {
				if (other.accessorClassInfo != null)
					return false;
			} else if (!accessorClassInfo.equals(other.accessorClassInfo))
				return false;
			return true;
		}		
		
	}	*/
	
	public InstanceRegionChecker() {
		this.instanceRegions = new HashMap<Integer, Integer>();
	}

	@Override
	public void instructionExecuted(JVM vm) {
		ClassInfo lastClassInfo = vm.getLastClassInfo();
		Instruction instruction = vm.getLastInstruction();
		if (instruction instanceof NEW) {
			long a = 1;
		}
		if ((lastClassInfo.getAnnotation(InstanceRegion.class.getCanonicalName()) != null)
				&& (instruction instanceof NEW)) {
			registerNewInstanceRegion((NEW) instruction, lastClassInfo);
		} else if (instruction instanceof PUTFIELD) {
			checkInstanceRegionViolation((PUTFIELD) instruction);
		} else if (instruction instanceof PUTSTATIC) {
			
		}
	}	

	private void registerNewInstanceRegion(NEW newInstruction, ClassInfo ci) {
		instanceRegions.put(newInstruction.getNewObjectRef(), 0); 
	}
	
	private void checkInstanceRegionViolation(PUTFIELD putfieldInstruction) {
		Integer objectRef = (int) putfieldInstruction.getLastValue();		
//		Set<InstanceRegionAccessInfo> accessInfos = instanceRegions.get(objectRef);
		Integer accessInfo = instanceRegions.get(objectRef);
		int thisref = putfieldInstruction.getLastThis();		
		// the object is annotated with InstanceRegion
		if (accessInfo != null && accessInfo == 0) {
			// ClassInfo putter = putfieldInstruction.getMethodInfo().getClassInfo();			
			instanceRegions.put(objectRef, thisref);
		} else if (accessInfo != null && thisref != accessInfo) {
			StringBuilder message = new StringBuilder();
			message.append("InstanceRegionViolation detected in ");
			message.append(putfieldInstruction.getMethodInfo().getName());
			Instruction nextPc = 
				ThreadInfo.getCurrentThread().createAndThrowException("java.lang.AssertionError", message.toString());
			ThreadInfo.getCurrentThread().setNextPC(nextPc);
		}
	}
	
	
}
