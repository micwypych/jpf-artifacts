package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.jvm.StackFrame;

public class DefaultSelfConfinedFieldInfo extends DefaultConfinedFieldInfo implements SelfConfinedFieldInfo {

	public DefaultSelfConfinedFieldInfo(
			RegionRestrictionInfo regionRestriction,
			ClassesRestrictionInfo classesRestriction, boolean reference,
			boolean value) {
		super(regionRestriction, classesRestriction, reference, value);
	}

	private int ownerReference;
	
	@Override
	public void setOwnerReference(int this1) {
		this.ownerReference = this1;
	}

	@Override
	public boolean isSelf() {
		return true;
	}

	@Override
	public boolean isConfinedContext(StackFrame sf) {
		return sf.getThis() == ownerReference;
	}

	@Override
	public boolean isEmpty() {
		return false;
	}	

}
