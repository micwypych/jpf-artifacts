package gov.nasa.jpf.aprop.region.util;

import gov.nasa.jpf.jvm.ClassInfo;

import java.util.Comparator;

/**
 * Encapsulation of class info comparator.
 * Comparator is based on unique id of class info. 
 */
public final class ClassInfoComparator implements Comparator<ClassInfo> {

	@Override
	public int compare(ClassInfo o1, ClassInfo o2) {
		return o1.getUniqueId() - o2.getUniqueId();
	}
}
