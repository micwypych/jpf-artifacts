//
// Copyright (C) 2006 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.aprop.region.util.MethodInfoComparator;
import gov.nasa.jpf.jvm.MethodInfo;

import java.util.Set;
import java.util.TreeSet;

/**
 * Class holding information about methods belonging to the dynamic region. 
 */
public class DynamicRegionInfo {

	/**
	 * MethodInfo which was the starting point of dynamic region.
	 */
	private MethodInfo dynamicRegionStart;
	
	/**
	 * MethodInfos belonging to dynamic region. 
	 */
	private Set<MethodInfo> dynamicRegionMethods;
	
	/**
	 * Comparator of methods.
	 */
	private MethodInfoComparator methodInfoComparator;
	
	/**
	 * Name of the dynamic region.
	 */
	private String regionName;

	public DynamicRegionInfo(String regionName) {
		super();
		this.regionName = regionName;
		this.methodInfoComparator = new MethodInfoComparator();
		this.dynamicRegionMethods = new TreeSet<MethodInfo>(this.methodInfoComparator);
	}

	/**
	 * Adds method info to dynamic region. 
	 * 
	 * @param mi
	 */
	public void addMethodToDynamicRegion(MethodInfo mi) {
		if (dynamicRegionStart == null) {
			dynamicRegionStart = mi;
		} else {
			dynamicRegionMethods.add(mi);
		}
	}
	
	/**
	 * Removes method info from dynamic region.  
	 * 
	 * @param mi
	 */
	public void removeMethodFromDynamicRegion(MethodInfo mi) {
		dynamicRegionMethods.remove(mi);
	}
	
	/**
	 * Exits dynamic region. Removes all method infos.
	 */
	public Set<MethodInfo> exit() {
		Set<MethodInfo> result = new TreeSet<MethodInfo>(this.methodInfoComparator);
		result.addAll(dynamicRegionMethods);
		result.add(dynamicRegionStart);
		dynamicRegionMethods.clear();
		dynamicRegionStart = null;
		return result;
	}
	
	/**
	 * Returns if this dynamic region has given method.
	 * 
	 * @param mi
	 * @return
	 */
	public boolean hasMethodInfo(MethodInfo mi) {
		if (dynamicRegionStart != null && methodInfoComparator.compare(mi, dynamicRegionStart) == 0) 
			return true;
		return dynamicRegionMethods.contains(mi);
	}

	/**
	 * Returns region name.
	 * 
	 * @return
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * Sets dynamic region start method.
	 * 
	 * @param dynamicRegionStart
	 */
	public void setDynamicRegionStart(MethodInfo dynamicRegionStart) {
		this.dynamicRegionStart = dynamicRegionStart;
	}
}
