package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.jvm.MethodInfo;

/**
 * A default implementation of the confined method info. 
 */
public class DefaultConfinedMethodInfo extends DefaultConfinedInfo implements ConfinedMethodInfo {

	public DefaultConfinedMethodInfo(RegionRestrictionInfo regionRestriction,
			ClassesRestrictionInfo classesRestriction) {
		super(regionRestriction, classesRestriction);
	}

	@SuppressWarnings("deprecation") // <2do> fix
  @Override
	public boolean isConfinedMethodCall(MethodInfo invokingMethodInfo) {
		boolean result = super.regionRestriction().allowsUsage(invokingMethodInfo.getClassName());
		if (!result) 
			result = this.regionRestriction().allowsUsage(invokingMethodInfo);
		return result;		
	}

	@Override
	public boolean isMethodConfined() {
		return true;
	}
}