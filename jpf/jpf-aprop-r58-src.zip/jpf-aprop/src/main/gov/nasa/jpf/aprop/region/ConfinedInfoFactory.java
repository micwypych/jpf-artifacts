package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.annotation.ConfinedExecutable;
import gov.nasa.jpf.annotation.ConfinedField;
import gov.nasa.jpf.annotation.ConfinedType;
import gov.nasa.jpf.annotation.Self;
import gov.nasa.jpf.aprop.region.RestrictionInfoParser.RestrictionParserResult;
import gov.nasa.jpf.jvm.AnnotationInfo;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.FieldInfo;
import gov.nasa.jpf.jvm.InfoObject;
import gov.nasa.jpf.jvm.MethodInfo;

/**
 * Heart of translation between annotations (source model) and constructs 
 * understandable by confined checkers. Basically, parses the information
 * in annotations and returns ConfinedInfo for them. 
 */
public class ConfinedInfoFactory {

	private RestrictionInfoParser restrictionParser;

	public ConfinedInfoFactory() {
		this.restrictionParser = new RestrictionInfoParser();
	}
	
	public ConfinedInfo typeInfo(ClassInfo ci) {
		ClassInfo enc = ci.getEnclosingClassInfo();
		ConfinedInfo enclosingConfinedInfo = DefaultConfinedInfo.emptyConfinedInfo();
		RestrictionParserResult parserResult = null;
		// first, iterate trough all enclosing classes
		while (enc != null) {		
			AnnotationInfo ai = ci.getAnnotation(ConfinedType.class.getCanonicalName());
			if (ai != null) {
				parserResult = restrictionParser.parse(ai.getValueAsStringArray("to"));
				parserResult.getClassesRestriction().setSelf(ci.getName());
				if (!enclosingConfinedInfo.isEmpty())
					parserResult = parserResult.intersection(enclosingConfinedInfo);
				enclosingConfinedInfo = new DefaultConfinedTypeInfo(parserResult.getRegionRestriction(), 
						parserResult.getClassesRestriction(), 
						ai.getValue("instance", Boolean.class), 
						ai.getValue("type", Boolean.class));
			}	
			enc = enc.getEnclosingClassInfo();
		}
		ClassInfo superc = ci.getSuperClass();
		ConfinedTypeInfo ct = DefaultConfinedTypeInfo.emptyConfinedInfo();
		// iterate trough all super classes
		while (superc != null) {
			AnnotationInfo ai = ci.getAnnotation(ConfinedType.class.getCanonicalName());
			if (ai != null) {
				parserResult = restrictionParser.parse(ai.getValueAsStringArray("to"));
				parserResult.getClassesRestriction().setSelf(ci.getName());
				if (!enclosingConfinedInfo.isEmpty())
					parserResult = parserResult.intersection(enclosingConfinedInfo);
				enclosingConfinedInfo = new DefaultConfinedTypeInfo(parserResult.getRegionRestriction(), 
						parserResult.getClassesRestriction(), 
						ai.getValue("instance", Boolean.class), 
						ai.getValue("type", Boolean.class));	
			}
			superc = superc.getSuperClass();
		}
		if (parserResult != null) {
			parserResult = parserResult.intersection(enclosingConfinedInfo);
			return new DefaultConfinedTypeInfo(parserResult.getRegionRestriction(), 
					parserResult.getClassesRestriction(), ct.instance(), ct.type());
		}
		else
			return enclosingConfinedInfo;
	}
	
	public ConfinedInfo memberInfo(InfoObject io, ConfinedInfo containerInfo) {
		if (io instanceof FieldInfo)
			return fieldInfo((FieldInfo) io, containerInfo);
		else if (io instanceof MethodInfo)
			return methodInfo((MethodInfo) io, containerInfo);
		else 
			return DefaultConfinedInfo.emptyConfinedInfo();
	}

	/**
	 * Parses and encapsulated information from @ConfinedField annotation.
	 * 
	 * @param io
	 * @param containerInfo
	 * @return
	 */
	private ConfinedInfo fieldInfo(FieldInfo io,  ConfinedInfo containerInfo) {
		AnnotationInfo ai = io.getAnnotation(ConfinedField.class.getCanonicalName());
		ConfinedFieldInfo result = DefaultConfinedFieldInfo.emptyConfinedInfo();
		if (io.getAnnotation(Self.class.getCanonicalName()) != null)
			return selfField(io);
		if (ai != null) {
			RestrictionParserResult parserResult = restrictionParser.parse(ai.getValueAsStringArray("to"));
			parserResult.getClassesRestriction().setSelf(io.getClassInfo().getName());
			result = new DefaultConfinedFieldInfo(parserResult.getRegionRestriction(), 
					parserResult.getClassesRestriction(), 
					ai.getValue("reference", Boolean.class), 
					ai.getValue("value", Boolean.class));
		} 
		if (!containerInfo.isEmpty() && !result.isEmpty()) {
			ClassesRestrictionInfo cri = ClassesRestrictionInfo.intersection(containerInfo.classesRestriction(), result.classesRestriction());
			cri.setSelf(io.getClassInfo().getName());
			return new DefaultConfinedFieldInfo(
					RegionRestrictionInfo.intersection(containerInfo.regionRestriction(), result.regionRestriction()), 
					cri, 
					result.reference(), result.value());
		}
		else if (result.isEmpty()) {
			ConfinedFieldInfo cfi = new DefaultConfinedFieldInfo(containerInfo.regionRestriction(), 
					containerInfo.classesRestriction(), true, true);
			cfi.classesRestriction().setSelf(io.getClassInfo().getName());
			return cfi;
		}
		else if (containerInfo.isEmpty())
			return result;
		return DefaultConfinedFieldInfo.emptyConfinedInfo();
	}

	private ConfinedInfo selfField(FieldInfo io) {
		AnnotationInfo ai = io.getAnnotation(Self.class.getCanonicalName());
		if (ai != null) {
			return new DefaultSelfConfinedFieldInfo(new RegionRestrictionInfo(), new ClassesRestrictionInfo(), 
				ai.getValue("reference", Boolean.class), 
				ai.getValue("value", Boolean.class));
		}
		return DefaultConfinedFieldInfo.emptyConfinedInfo();
	}

	/**
	 * Parses data in @ConfinedMethod or @ConfinedConstructor annotation and
	 * returns an instance of ConfinedInfo.
	 * 
	 * @param io
	 * @param containerInfo
	 * @return
	 */
	private ConfinedInfo methodInfo(MethodInfo io, ConfinedInfo containerInfo) {
		AnnotationInfo ai = io.getAnnotation(ConfinedExecutable.class.getCanonicalName());
		if (ai != null) {
			RestrictionParserResult parserResult = restrictionParser.parse(ai.getValueAsStringArray());
			parserResult.getClassesRestriction().setSelf(io.getClassInfo().getName());
			parserResult.intersection(containerInfo);
			if (!containerInfo.isEmpty())
				parserResult = parserResult.intersection(containerInfo);
			return new DefaultConfinedMethodInfo(parserResult.getRegionRestriction(), 
					parserResult.getClassesRestriction());
		} else {
			return DefaultConfinedInfo.emptyConfinedInfo();
		}
	}

}
