//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region.util;

import gov.nasa.jpf.jvm.ClassInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class extending class info with methods related to super class.
 */
public class SuperClassUtil {

	/**
	 * Returns list of classes which are super classes of this class.
	 * 
	 * @param ci - class info
	 * @return - list of super classes of class info from parameter
	 */
	public List<ClassInfo> getSuperClasses(ClassInfo ci) {
		List<ClassInfo> superClasses = new ArrayList<ClassInfo>();
		ClassInfo superClass = ci;
		while (superClass.getSuperClass() != null) {
			superClass = superClass.getSuperClass();
			superClasses.add(0, superClass);
		}
		return superClasses;
	}

}
