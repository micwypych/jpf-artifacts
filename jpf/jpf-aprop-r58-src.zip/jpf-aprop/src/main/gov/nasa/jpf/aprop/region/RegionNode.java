//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.aprop.exception.RegionWideningException;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.MethodInfo;

import java.util.HashSet;
import java.util.Set;

/**
 * Encapsulation of region's tree node. 
 */
public class RegionNode {

	/**
	 * Child nodes of this region node.
	 */
	private Set<RegionNode> children;
	
	/**
	 * Classes belonging to this region node.
	 */
	private Set<ClassInfo> classes;
	
	/**
	 * Dynamic region info associated with this region node.
	 */
	private DynamicRegionInfo dynamicRegionInfo;
	
	/**
	 * Parent of this region node.
	 */
	private RegionNode parent;
	
	/**
	 * Region name.
	 */
	private String regionName;
	
	/**
	 * Type of the region node.
	 */
	private final RegionNodeType type;
	
	/**
	 * RegionNode constructor.
	 * 
	 * @param regionName
	 */
	protected RegionNode(String regionName) {
		this(regionName, RegionNodeType.NODE);
	}
	
	private RegionNode(String regionName, RegionNodeType type) {
		super();
		this.children = new HashSet<RegionNode>();
		this.classes = new HashSet<ClassInfo>();
		this.dynamicRegionInfo = new DynamicRegionInfo(regionName);
		this.regionName = regionName;
		this.type = type;
	}
	
	private RegionNode(RegionNodeType rnt) {
		this(null, rnt);
	}
	
	/**
	 * Creates new region node, which is child of this region node.
	 * 
	 * @param regionName
	 */
	protected void addChild(String regionName) {
		if (!RegionsUtil.matchesRegionPattern(regionName))
			throw new RegionWideningException("Illegal region name " + regionName);
		String newRegionHeadName = regionName;
		String newRegionSubName = regionName;
		if (regionName.contains(".")) {
			newRegionHeadName = RegionsUtil.getHeadRegion(regionName);
			newRegionSubName = RegionsUtil.getSubRegions(regionName);
		}
		boolean newRegionParentExists = false;
		for (RegionNode rn : children) {
			if (rn.regionName.equals(newRegionHeadName)) {
				newRegionParentExists = true;
				if (!newRegionSubName.equals(regionName))
					rn.addChild(newRegionSubName);
				break;
			}
		}
		if (!newRegionParentExists) {
			RegionNode rn = new RegionNode(newRegionHeadName);
			rn.parent = this;
			children.add(rn);
			if (!newRegionHeadName.equals(newRegionSubName))
				rn.addChild(newRegionSubName);
		}		
	}

	/**
	 * Returns child with given region name.
	 * 
	 * @param regionName
	 * @return
	 */
	protected RegionNode getChild(String regionName) {
		if (!RegionsUtil.matchesRegionPattern(regionName))
			throw new RegionWideningException("Illegal region name " + regionName);
		regionName = RegionsUtil.stripPrefix(regionName);
		String newRegionHeadName = regionName;
		String newRegionSubName = regionName;
		if (regionName.contains(".")) {
			newRegionHeadName = RegionsUtil.getHeadRegion(regionName);
			newRegionSubName = RegionsUtil.getSubRegions(regionName);
		}
		if (children.isEmpty())
			return this;
		for (RegionNode rn : children) {
			if (rn.regionName.equals(newRegionHeadName)) {
				if (regionName.equals(newRegionHeadName)) {
					return rn;
				} else {
					return rn.getChild(newRegionSubName);
				}
			}
		}
		return emptyRegionNode();
	}

	/**
	 * Adds class info to the region. 
	 * 
	 * @param classInfo
	 */
	protected void addClassInfo(ClassInfo classInfo) {
		classes.add(classInfo);
	}

	/**
	 * Returns if this region node or its parents contains specified class.
	 * 
	 * @param classInfo - name of the class to find
	 * @return
	 */
	public boolean hasClassInfo(String classInfo) {
		for (ClassInfo ci : classes) {
			if (ci.getName().equals(classInfo))
				return true;
		}
		if (parent != null && !parent.type.equals(RegionNodeType.ROOT)) 
			return parent.hasClassInfo(classInfo);
		else 
			return false;
	}
	
	/**
	 * Adds method info to dynamic region.
	 * 
	 * @param methodInfo
	 */
	public void addMethodInfo(MethodInfo methodInfo) {
		dynamicRegionInfo.addMethodToDynamicRegion(methodInfo);
	}
	
	/**
	 * Exits dynamic region and returns set of all methods from region.
	 */
	public Set<MethodInfo> exitDynamicRegion() {
		return dynamicRegionInfo.exit();
	}
	
	/**
	 * Exits dynamic region.
	 * 
	 * @param methodInfo - method which has exit dynamic region. 
	 */
	public void exitDynamicRegion(MethodInfo methodInfo) {
		dynamicRegionInfo.removeMethodFromDynamicRegion(methodInfo);
	}
	
	public boolean hasMethodInfo(MethodInfo methodInfo) {
		return dynamicRegionInfo.hasMethodInfo(methodInfo);
	}
	
	/**
	 * Returns region node which is root to other regions. 
	 * 
	 * @return root region node.
	 */
	protected static RegionNode getRoot() {
		return new RegionNode(RegionNodeType.ROOT);
	}
	
	/**
	 * Returns empty region node. 
	 * 
	 * @return empty region node.
	 */
	protected static RegionNode emptyRegionNode() {
		return new RegionNode(RegionNodeType.EMPTY);
	}
	
	/**
	 * Returns if the node is empty.
	 * 
	 * @return
	 */
	protected boolean isEmpty() {
		return this.type.equals(RegionNodeType.EMPTY);
	}
	
	public String getRegionName() {
		if (parent.type.equals(RegionNodeType.ROOT)) {
			return this.regionName;
		} else {
			return parent.getRegionName() + "." + regionName;
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((parent == null) ? 0 : parent.hashCode());
		result = prime * result
				+ ((regionName == null) ? 0 : regionName.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegionNode other = (RegionNode) obj;
		if (parent == null) {
			if (other.parent != null)
				return false;
		} else if (!parent.equals(other.parent))
			return false;
		if (regionName == null) {
			if (other.regionName != null)
				return false;
		} else if (!regionName.equals(other.regionName))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegionNode [regionName=" + regionName + ", type=" + type + "]";
	}
	
}
