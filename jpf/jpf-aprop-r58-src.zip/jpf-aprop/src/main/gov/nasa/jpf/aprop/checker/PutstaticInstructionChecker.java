package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.jvm.bytecode.FieldInstruction;
import gov.nasa.jpf.jvm.bytecode.PUTSTATIC;

/**
 * Checker for PUTSTATIC instruction.
 * 
 * @see gov.nasa.jpf.jvm.bytecode.PUTSTATIC
 */
public class PutstaticInstructionChecker extends FieldStoreInstructionChecker {


	@Override
	protected <T extends FieldInstruction> int getObjectRef(T fieldInstruction) {
		return (int) ((PUTSTATIC) fieldInstruction).getLastValue();
	}

	@Override	
	protected <T extends FieldInstruction> int getThis(T fieldInstruction) {
		return 0;
	}
}
