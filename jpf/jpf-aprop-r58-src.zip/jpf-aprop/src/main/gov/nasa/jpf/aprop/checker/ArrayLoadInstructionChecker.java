package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.checker.GetInstructionChecker.GetViolationAttribute;
import gov.nasa.jpf.aprop.region.ConfinedInfo;
import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;

import java.util.Iterator;

/**
 * Checks for array load instruction. 
 * When confined array is being accessed, stack frame attribute is transited
 * from array to array element.   
 */
public class ArrayLoadInstructionChecker implements VMChecker {

	public void check(JVM vm) {
		ThreadInfo threadInfo = vm.getLastThreadInfo();
		ElementInfo ei = vm.getLastElementInfo();
		int objectRef = ei.getObjectRef();
		EarlyRegionEndViolationAttribute violationAttribute = 
			ei.getObjectAttr(EarlyRegionEndViolationAttribute.class);
		if (violationAttribute != null) {
			ConfinedInfo confinedInfo = violationAttribute.getConfinedInfo();
			Iterator<StackFrame> sfIterator = threadInfo.iterator();
			while (sfIterator.hasNext()) {
				StackFrame sf = sfIterator.next();
				if (!confinedInfo.isConfinedContext(sf)) {
					sf.getLocalAttr(0, GetViolationAttribute.class).setObjectRef(objectRef);
					break;
				}
			}
		}
	}


}
