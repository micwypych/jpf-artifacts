//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.annotation.Region;
import gov.nasa.jpf.aprop.exception.IllegalRegionNameException;
import gov.nasa.jpf.aprop.exception.RegionWideningException;
import gov.nasa.jpf.aprop.region.util.EnclosingClassUtil;
import gov.nasa.jpf.aprop.region.util.MethodInfoComparator;
import gov.nasa.jpf.jvm.AnnotationInfo;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.MethodInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Singleton holding and encapsulating regions tree structure.  
 */
public class RegionTreeContainer {

	/**
	 * RegionTreeContainer is a singleton. The only instance of the class. 
	 */
	private static RegionTreeContainer instance;
	
	/**
	 * Root of the region tree. 
	 */
	private RegionNode root;
	
	/**
	 * Map holding information about dynamic regions associated with methods. 
	 * Used for optimization. 
	 */
	private Map<MethodInfo, Set<String>> dynamicRegionsMap;

	/**
	 * Returns non-null instance of the class. 
	 * 
	 * @return
	 */
	public static RegionTreeContainer getInstance() {
		if (instance == null) {
			instance = new RegionTreeContainer();
		}
		return instance;
	}

	private RegionTreeContainer() {
		super();
		this.root = RegionNode.getRoot();
		this.dynamicRegionsMap = new TreeMap<MethodInfo, Set<String>>(new MethodInfoComparator());
	}

	/**
	 * Adds class to regions with respect to its annotation values. 
	 * 
	 * @see gov.nasa.jpf.region.annotation.Region
	 * @see gov.nasa.jpf.region.annotation.InstanceRegion
	 * 
	 * @param ci
	 */
	public synchronized void addClassToRegion(ClassInfo ci) {
		AnnotationInfo ai = ci.getAnnotation(Region.class.getCanonicalName());
		for (String annotValue : ai.getValueAsStringArray()) {
			root.addChild(annotValue);
			root.getChild(annotValue).addClassInfo(ci);
		}
	}

	public synchronized void processClasses(ClassInfo ci, List<RegionNode> enclosingRegions) {
		EnclosingClassUtil enclosingClassUtil = new EnclosingClassUtil(); 
		List<ClassInfo> enclosingClasses = enclosingClassUtil.getEnclosingClasses(ci);
		enclosingClasses.add(ci);
		for (ClassInfo classInfo : enclosingClasses) {
			AnnotationInfo ai = classInfo.getAnnotation(Region.class.getCanonicalName());
			if (ai != null) {
				enclosingRegions = processNarrowingAnnotation(ai.getValueAsStringArray(), ci, enclosingRegions);
			}
		}
	}
	
	private List<RegionNode> processNarrowingAnnotation(String[] values, 
			ClassInfo ci, List<RegionNode> enclosingRegions) {
		List<RegionNode> thisEnclosingRegions = new ArrayList<RegionNode>();
		for (String annotValue : values) {
			if (!RegionsUtil.matchesRegionPattern(annotValue)) {
				throw new IllegalRegionNameException("Illegal region name " + annotValue);
			}
			if (RegionsUtil.widens(enclosingRegions, annotValue)) {
				throw new RegionWideningException(annotValue + " widens enclosing set " + enclosingRegions);
			}
			root.addChild(annotValue);
			RegionNode rn = root.getChild(annotValue);
			rn.addClassInfo(ci);
			thisEnclosingRegions.add(rn);
		}
		return thisEnclosingRegions;
	}

	public synchronized List<RegionNode> processPackage(ClassInfo ci) {
		if (ci.isSystemClass() || ci.isPrimitive()) // prohibited 
			return Collections.emptyList();
		Class<?> clazz = null;
		try {
			clazz = Class.forName(ci.getName());
		} catch (Exception e) {
			return Collections.emptyList();
		}
		Region packageRegion = null;
		if (clazz.getPackage() != null && 
				(packageRegion = clazz.getPackage().getAnnotation(Region.class)) != null ) {
			return processNonNarrowingAnnotation(packageRegion.value(), ci);
		} else {
			return Collections.emptyList();
		}
	}
	
	private List<RegionNode> processNonNarrowingAnnotation(String[] values, ClassInfo ci) {
		List<RegionNode> packageRegions = new ArrayList<RegionNode>();
		for (String annotValue : values) {
			if (!RegionsUtil.matchesRegionPattern(annotValue)) {
				throw new IllegalRegionNameException("Illegal region name " + annotValue);
			}
			root.addChild(annotValue);
			RegionNode rn = root.getChild(annotValue);
			rn.addClassInfo(ci);
			packageRegions.add(rn);
		}	
		return packageRegions;
	}

	/**
	 * Returns region node for given region name.
	 * 
	 * 
	 * @see gov.nasa.jpf.region.regions.RegionNode
	 * 
	 * @param regionName
	 * @return
	 */
	public synchronized RegionNode getNodeForRegion(String regionName) {
		return root.getChild(regionName);
	}

	/**
	 * Adds information about method to given region name.
	 * 
	 * @param methodInfo
	 * @param regionName
	 */
	public synchronized void addMethodInfoToRegion(MethodInfo methodInfo, String regionName) {
		if (dynamicRegionsMap.get(methodInfo) == null) {
			Set<String> regions = new HashSet<String>();
			regions.add(regionName);
			dynamicRegionsMap.put(methodInfo, regions);
		} else {
			dynamicRegionsMap.get(methodInfo).add(regionName);
		}
		root.addChild(regionName);
		root.getChild(regionName).addMethodInfo(methodInfo);
	}
	
	/**
	 * Transit dynamic regions associated with invoking method info to 
	 * invoked method info. 
	 * 
	 * @param from
	 * @param to
	 */
	public synchronized void transitDynamicRegion(MethodInfo from, MethodInfo to) {
		Set<String> fromRegions = dynamicRegionsMap.get(from);
		for (String region : fromRegions) {
			addMethodInfoToRegion(to, region);
		}
	}
	
	/**
	 * Returns if method is in dynamic region. 
	 * 
	 * @param methodInfo
	 * @return
	 */
	public synchronized boolean isMethodInDynamicRegion(MethodInfo methodInfo) {
		return dynamicRegionsMap.get(methodInfo) != null;
	}
	
	/**
	 * Terminates dynamic region.
	 * 
	 * @param regionName
	 */
	public synchronized void exitRegion(String regionName) {
		Set<MethodInfo> methods = root.getChild(regionName).exitDynamicRegion();
		for (MethodInfo mi : methods) {
			dynamicRegionsMap.remove(mi);
		}
	}
	
	/**
	 * Exits dynamic region.
	 * 
	 * @param methodInfo - method exiting dynamic region.
	 * @param regionName
	 */
	public synchronized void exitRegion(MethodInfo methodInfo, String regionName) {
		root.getChild(regionName).exitDynamicRegion(methodInfo);
		dynamicRegionsMap.get(methodInfo).remove(regionName);
	}

	/**
	 * Exits dynamic region. 
	 * 
	 * @param methodInfo
	 */
	public synchronized void exitRegion(MethodInfo methodInfo) {
		Set<String> regions = dynamicRegionsMap.get(methodInfo);
		for (String region : regions) {
			root.getChild(region).exitDynamicRegion(methodInfo);
		}
		dynamicRegionsMap.get(methodInfo).clear();
	}
}
