package gov.nasa.jpf.aprop.region;

/**
 * Interface for objects holding information about confined fields. 
 * 
 */
public interface ConfinedFieldInfo extends ConfinedInfo {
	
	/**
	 * Returns true if the object's reference is confined.
	 * @return
	 */
	boolean reference();
	
	/**
	 * Returns true if the object is confined.
	 * @return
	 */
	boolean value();

	boolean isSelf();
}
