package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.jvm.JVM;

/**
 * VM checker conducting check for contract violation of the currently executed
 * instruction
 */
public interface VMChecker {

	/**
	 * Check for a violation.  
	 * 
	 * @param vm - virtual machine to check.
	 */
	void check(JVM vm);
}
