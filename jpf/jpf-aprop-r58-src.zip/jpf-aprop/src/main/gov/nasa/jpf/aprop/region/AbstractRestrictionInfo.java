//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;


import gov.nasa.jpf.aprop.exception.ConfinedException;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract class holding information about a confined set of classes
 * or regions. Specifies methods for narrowing the set and methods
 * deciding whether caller is listed on class/regions list. 
 *
 */
public abstract class AbstractRestrictionInfo {

	private static final class RestrictionWideningException extends ConfinedException {
		private static final long serialVersionUID = -4286321825919458362L;

		public RestrictionWideningException(String message) {
			super(message);
		}
		
	}
	
	protected List<String> value;

	public AbstractRestrictionInfo() {
		super();
		value = new ArrayList<String>();
	}
	
	/**
	 * Creates a restriction info as the intersection of two
	 * other restrictions.
	 * 
	 * @param x
	 * @param y
	 */
	public AbstractRestrictionInfo(AbstractRestrictionInfo x, AbstractRestrictionInfo y) {
		this();
		for (String xValue : x.value) {
			if (y.value.contains(xValue))
				value.add(xValue);
		}
	}
	
	/**
	 * Decides whether the caller (region or class) is confined.  
	 * 
	 * @param caller - class/region to check.
	 * @return
	 */
	public abstract boolean allowsUsage(String caller);
	
	/**
	 * Returns deep copy of the object. 
	 * 
	 * @return
	 */
	public abstract AbstractRestrictionInfo deepCopy();
	
	/**
	 * Adds new confined region or class. 
	 * 
	 * @param s
	 */
	public abstract void addConfinee(String s);
	
	/**
	 * Checks whether a given region or a class name narrows
	 * confined class name or region.  
	 * 
	 * @param existing
	 * @param narrower
	 * @return
	 */
	protected abstract boolean narrows(String existing, String narrower);
	
	/**
	 * Returns true if no element is confined.
	 * 
	 * @return
	 */
	protected abstract boolean isEmpty();
	
	/**
	 * Checks whether a given region or a class name widens 
	 * a confined class name or region.  
	 * 
	 * @param existing
	 * @param widener
	 * @return
	 */
	public boolean widens(String existing, String widener) {
		return !narrows(existing, widener);
	}
	
	/**
	 * Iterates through all confined values.
	 * If the given value narrows any of the confined 
	 * classes or regions, replaces the value.   
	 * 
	 * @param narrower
	 */
	public void narrowRestriction(String narrower) {
		boolean found = false;
		for (String v : value) {
			if (narrows(v, narrower)) {
				found = true;
				value.remove(v);
				value.add(stripPrefix(narrower));
				break;
			}
		}
		if (!found)
			throw new RestrictionWideningException(narrower + " widens " + value);
	}
	
	public boolean narrows(String narrower) {
		boolean found = false;
		for (String v : value) {
			if (narrows(v, narrower)) {
				found = true;
				break;
			}
		}	
		if (!found) 
			throw new RestrictionWideningException(narrower + " widens " + value);
		return found;
	}
	
	/**
	 * Narrows the confined set to the new list of confinees. 
	 * 
	 * @param narrowingSet
	 */
	public void narrowRestrictions(String[] newConfinees) {
		for (String narrower : newConfinees) {
			narrowRestriction(narrower);
		}
	}	
	
	protected abstract String stripPrefix(String value);
}
