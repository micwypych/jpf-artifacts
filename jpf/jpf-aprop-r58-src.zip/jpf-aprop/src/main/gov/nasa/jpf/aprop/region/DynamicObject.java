package gov.nasa.jpf.aprop.region;

public class DynamicObject {

	public native static void confine(Object object, String[] args);
	
}
