//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.jvm.MethodInfo;

/**
 * Encapsulation of confined regions restriction.
 * 
 * TODO refactor
 */
public class RegionRestrictionInfo extends AbstractRestrictionInfo {
	
	public RegionRestrictionInfo() {
		super();
	}
	
	public RegionRestrictionInfo(RegionRestrictionInfo x, RegionRestrictionInfo y) {
		super(x,y);
	}
	
	@Override
	public void addConfinee(String regionName) {
		validateRegioName(regionName);
		value.add(stripPrefix(regionName));
	}

	private void validateRegioName(String regionName) {
		//if (!RegionsUtil.matchesRegionPattern(regionName))
		//	throw new IllegalRegionNameException("Illegal region name " + regionName);
	}


	public boolean allowsUsage(MethodInfo methodInfo) {
		for (String region : value) {
			RegionNode rn = RegionTreeContainer.getInstance().getNodeForRegion(region);
			if (rn.hasClassInfo(methodInfo.getClassName()) || rn.hasMethodInfo(methodInfo)) {
				return true;
			}
		}
		return false;
	}	
	
	@Deprecated // <2do> pcm - what is it supposed to be replaced with?
	@Override
	public boolean allowsUsage(String caller) {
		return false;
	}

	@Override
	public AbstractRestrictionInfo deepCopy() {
		RegionRestrictionInfo rri = new RegionRestrictionInfo();
		for (String s : value) {
			rri.value.add(new String(s));
		}
		return rri;
	}

	@Override
	protected boolean narrows(String existing, String narrower) {
		narrower = stripPrefix(narrower);
		return narrower.startsWith(existing);
	}

	@Override
	protected boolean isEmpty() {
		return value.isEmpty();
	}

	@Override
	public String toString() {
		return "RegionRestrictionInfo [value=" + value + "]";
	}

	/**
	 * Regions names are represented by string prefixed with # char. This method strips 
	 * the char from the region name.  
	 * 
	 * @param value - region's name
	 * @return
	 */
	@Override
	protected String stripPrefix(String value) {
		//return RegionsUtil.stripPrefix(value);
		return value;
	}

	public static RegionRestrictionInfo intersection(RegionRestrictionInfo inner,
			RegionRestrictionInfo outer) {
		RegionRestrictionInfo info = new RegionRestrictionInfo();
		for (String x : inner.value) {
			if (outer.value.contains(x))
				info.value.add(x);
		}
		return info;
	}
}
