package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.annotation.Region;

/**
 * Parser for restriction information provided in the annotation's value.
 */
public class RestrictionInfoParser {

	public static final class RestrictionParserResult {
		private ClassesRestrictionInfo classesRestriction;
		private RegionRestrictionInfo regionRestriction;		
		public RestrictionParserResult(
				ClassesRestrictionInfo classesRestriction,
				RegionRestrictionInfo regionRestriction) {
			this.classesRestriction = classesRestriction;
			this.regionRestriction = regionRestriction;
		}
		public ClassesRestrictionInfo getClassesRestriction() {
			return classesRestriction;
		}
		public RegionRestrictionInfo getRegionRestriction() {
			return regionRestriction;
		}
		
		/**
		 * Calculates the intersection of this restrictions with restrictions of 
		 * the other confined info.
		 *  
		 * @param containerInfo
		 * @return 
		 */
		public RestrictionParserResult intersection(ConfinedInfo containerInfo) {
			return new RestrictionParserResult(
					ClassesRestrictionInfo.intersection(this.classesRestriction, containerInfo.classesRestriction()),
					RegionRestrictionInfo.intersection(this.regionRestriction, containerInfo.regionRestriction()));
		}		
	}
	
	public RestrictionParserResult parse(String[] tos) {
		RegionRestrictionInfo regions = new RegionRestrictionInfo();
		ClassesRestrictionInfo classes = new ClassesRestrictionInfo();
		for (String t : tos) {
			if (t.startsWith(Region.REGION_PREFIX)) {
				regions.addConfinee(t);
			} else {
				classes.addConfinee(t);
			}
		}
		return new RestrictionParserResult(classes, regions);
	}
	
}
