package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.FieldInstruction;

public class GetStaticInstructionChecker extends GetInstructionChecker {

	@Override
	protected ElementInfo getElementInfo(FieldInstruction instruction,
			ThreadInfo ti) {
		return instruction.peekElementInfo(ti);
	}

}
