//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.listener;

import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.aprop.checker.ArrayLoadInstructionChecker;
import gov.nasa.jpf.aprop.checker.ArrayStoreInstructionChecker;
import gov.nasa.jpf.aprop.checker.GetFieldInstructionChecker;
import gov.nasa.jpf.aprop.checker.GetStaticInstructionChecker;
import gov.nasa.jpf.aprop.checker.HandleExceptionChecker;
import gov.nasa.jpf.aprop.checker.InvokeInstructionChecker;
import gov.nasa.jpf.aprop.checker.LocalVariableInstructionChecker;
import gov.nasa.jpf.aprop.checker.NewArrayInstructionChecker;
import gov.nasa.jpf.aprop.checker.PutfieldInstructionChecker;
import gov.nasa.jpf.aprop.checker.PutstaticInstructionChecker;
import gov.nasa.jpf.aprop.checker.ReturnInstructionChecker;
import gov.nasa.jpf.aprop.checker.ThrowExceptionChecker;
import gov.nasa.jpf.aprop.checker.VMChecker;
import gov.nasa.jpf.aprop.region.ConfinedInfoContainer;
import gov.nasa.jpf.aprop.region.util.RegionPropertiesReader;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.bytecode.AALOAD;
import gov.nasa.jpf.jvm.bytecode.AASTORE;
import gov.nasa.jpf.jvm.bytecode.ALOAD;
import gov.nasa.jpf.jvm.bytecode.ANEWARRAY;
import gov.nasa.jpf.jvm.bytecode.ARETURN;
import gov.nasa.jpf.jvm.bytecode.ASTORE;
import gov.nasa.jpf.jvm.bytecode.BALOAD;
import gov.nasa.jpf.jvm.bytecode.BASTORE;
import gov.nasa.jpf.jvm.bytecode.CALOAD;
import gov.nasa.jpf.jvm.bytecode.CASTORE;
import gov.nasa.jpf.jvm.bytecode.DALOAD;
import gov.nasa.jpf.jvm.bytecode.DASTORE;
import gov.nasa.jpf.jvm.bytecode.DLOAD;
import gov.nasa.jpf.jvm.bytecode.DRETURN;
import gov.nasa.jpf.jvm.bytecode.DSTORE;
import gov.nasa.jpf.jvm.bytecode.FALOAD;
import gov.nasa.jpf.jvm.bytecode.FASTORE;
import gov.nasa.jpf.jvm.bytecode.FLOAD;
import gov.nasa.jpf.jvm.bytecode.FRETURN;
import gov.nasa.jpf.jvm.bytecode.FSTORE;
import gov.nasa.jpf.jvm.bytecode.GETFIELD;
import gov.nasa.jpf.jvm.bytecode.GETSTATIC;
import gov.nasa.jpf.jvm.bytecode.IALOAD;
import gov.nasa.jpf.jvm.bytecode.IASTORE;
import gov.nasa.jpf.jvm.bytecode.ILOAD;
import gov.nasa.jpf.jvm.bytecode.INVOKECLINIT;
import gov.nasa.jpf.jvm.bytecode.INVOKEINTERFACE;
import gov.nasa.jpf.jvm.bytecode.INVOKESPECIAL;
import gov.nasa.jpf.jvm.bytecode.INVOKESTATIC;
import gov.nasa.jpf.jvm.bytecode.INVOKEVIRTUAL;
import gov.nasa.jpf.jvm.bytecode.IRETURN;
import gov.nasa.jpf.jvm.bytecode.ISTORE;
import gov.nasa.jpf.jvm.bytecode.Instruction;
import gov.nasa.jpf.jvm.bytecode.LALOAD;
import gov.nasa.jpf.jvm.bytecode.LASTORE;
import gov.nasa.jpf.jvm.bytecode.LLOAD;
import gov.nasa.jpf.jvm.bytecode.LRETURN;
import gov.nasa.jpf.jvm.bytecode.LSTORE;
import gov.nasa.jpf.jvm.bytecode.PUTFIELD;
import gov.nasa.jpf.jvm.bytecode.PUTSTATIC;
import gov.nasa.jpf.jvm.bytecode.RETURN;
import gov.nasa.jpf.jvm.bytecode.SALOAD;
import gov.nasa.jpf.jvm.bytecode.SASTORE;

import java.util.HashMap;
import java.util.Map;

/**
 * Check for @Confined violations.
 * 
 * @see http://bitbucket.org/rogaall/jpf-aprop-gsoc2010/wiki/Assumptions
 * @author Filip Rogaczewski
 *  
 */
public class ConfinedChecker extends ListenerAdapter {
	
	private Map<Class<? extends Instruction>, VMChecker> checkers;
	private VMChecker throwChecker;
	private VMChecker handleChecker;
	
	public ConfinedChecker() {
		super();
		initCheckers();
	}
	
	private void initCheckers() {
		checkers = new HashMap<Class<? extends Instruction>, VMChecker>();
		
		// return checker
		VMChecker returnChecker = new ReturnInstructionChecker();
		checkers.put(ARETURN.class, returnChecker);
		checkers.put(DRETURN.class, returnChecker);
		checkers.put(FRETURN.class, returnChecker);
		checkers.put(IRETURN.class, returnChecker);
		checkers.put(LRETURN.class, returnChecker);
		checkers.put(RETURN.class, returnChecker);
		
		// putfield
		checkers.put(PUTFIELD.class, new PutfieldInstructionChecker());
		checkers.put(PUTSTATIC.class, new PutstaticInstructionChecker());
		
		// getfield
		checkers.put(GETFIELD.class, new GetFieldInstructionChecker());
		checkers.put(GETSTATIC.class, new GetStaticInstructionChecker());
		
		// invoke checker
		VMChecker invokeChecker = new InvokeInstructionChecker();
		checkers.put(INVOKESPECIAL.class, invokeChecker);
		checkers.put(INVOKEINTERFACE.class, invokeChecker);
		checkers.put(INVOKESTATIC.class, invokeChecker);
		checkers.put(INVOKECLINIT.class, invokeChecker);
		checkers.put(INVOKEVIRTUAL.class, invokeChecker);

		
		// local variable checker
		VMChecker localVariableChecker = new LocalVariableInstructionChecker();
		checkers.put(LSTORE.class, localVariableChecker);
		checkers.put(LLOAD.class, localVariableChecker);
		checkers.put(ASTORE.class, localVariableChecker);
		checkers.put(ALOAD.class, localVariableChecker);
		checkers.put(DSTORE.class, localVariableChecker);
		checkers.put(DLOAD.class, localVariableChecker);
		checkers.put(FSTORE.class, localVariableChecker);
		checkers.put(FLOAD.class, localVariableChecker);
		checkers.put(ISTORE.class, localVariableChecker);
		checkers.put(ILOAD.class, localVariableChecker);
		
		// array checker
		VMChecker arrayChecker = new ArrayLoadInstructionChecker();
		checkers.put(AALOAD.class, arrayChecker);
		checkers.put(BALOAD.class, arrayChecker);
		checkers.put(CALOAD.class, arrayChecker);
		checkers.put(DALOAD.class, arrayChecker);
		checkers.put(FALOAD.class, arrayChecker);
		checkers.put(IALOAD.class, arrayChecker);
		checkers.put(LALOAD.class, arrayChecker);
		checkers.put(SALOAD.class, arrayChecker);
		
		
		// new array checker
		checkers.put(ANEWARRAY.class, new NewArrayInstructionChecker());
		
		VMChecker arrayStoreChecker = new ArrayStoreInstructionChecker();
		checkers.put(AASTORE.class, arrayStoreChecker);
		checkers.put(BASTORE.class, arrayStoreChecker);
		checkers.put(CASTORE.class, arrayStoreChecker);
		checkers.put(DASTORE.class, arrayStoreChecker);
		checkers.put(FASTORE.class, arrayStoreChecker);
		checkers.put(IASTORE.class, arrayStoreChecker);
		checkers.put(LASTORE.class, arrayStoreChecker);
		checkers.put(SASTORE.class, arrayStoreChecker);
		
		throwChecker = new ThrowExceptionChecker();
		handleChecker = new HandleExceptionChecker();
	}
	
	
	/* overridden listener notifications */
	
	@Override
	public void classLoaded(JVM vm) {
		ClassInfo lastCI = vm.getLastClassInfo();
		RegionPropertiesReader.instance(vm).parse(lastCI);
		ConfinedInfoContainer.instance().classLoaded(lastCI);
	}

	@Override
	public void instructionExecuted(JVM vm) {
		Instruction instruction = vm.getLastInstruction();
		VMChecker checker = checkers.get(instruction.getClass());
		if (checker != null) {
			checker.check(vm);
		}		
	}

	
	@Override
	public void exceptionHandled(JVM vm) {
		handleChecker.check(vm);
	}

	@Override
	public void exceptionThrown(JVM vm) {
		throwChecker.check(vm);
	}	
}
