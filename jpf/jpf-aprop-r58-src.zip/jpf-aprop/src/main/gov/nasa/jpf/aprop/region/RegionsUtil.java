//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.annotation.Region;

import java.util.List;

/**
 * Utility class encapsulating methods for regions 
 * narrowing, matching and extending.
 *
 */
public class RegionsUtil {

	private static final String REGION_NAME_PATTERN = 
		"^(([a-zA-Z][a-zA-Z_$0-9]*(\\.[a-zA-Z][a-zA-Z_$0-9]*)*)\\.)?([a-zA-Z][a-zA-Z_$0-9]*)$";
	
	public static boolean matchesRegionPattern(String regionName) {
		return stripPrefix(regionName).matches(REGION_NAME_PATTERN);
	}
	
	public static String stripPrefix(String value) {
		if (value.startsWith(Region.REGION_PREFIX))
			return value.substring(Region.REGION_PREFIX.length());
		else
			return value;
	}
	
	public static boolean narrows(String baseRegionName, String narrowingRegionName) {
		return narrowingRegionName.startsWith(baseRegionName);
	}
	
	public static boolean widens(String baseRegionName, String wideningRegionName) {
		return !narrows(baseRegionName, wideningRegionName);
	}
	
	public boolean matches(String baseRegionName, String otherRegionName) {
		return baseRegionName.equals(otherRegionName);
	}
	
	public static String getSubRegions(String regionName) {
		return regionName.substring(regionName.indexOf(".") + 1);
	}
	
	public static String getHeadRegion(String regionName) {
		return regionName.substring(0, regionName.indexOf("."));
	}
	
	/**
	 * Gets region node from regions list which is the exact region or parent
	 * region of region name from the parameter.
	 * 
	 * @param regions - list of regions.
	 * @param regionName - region name.
	 * @return - region node from the list for the parameter.
	 */
	public static boolean widens(List<RegionNode> regions, String regionName) {
		for (RegionNode rn : regions) {
			if (widens(rn.getRegionName(), regionName)) {
				return true;
			}
		}
		return false;
	}
}
