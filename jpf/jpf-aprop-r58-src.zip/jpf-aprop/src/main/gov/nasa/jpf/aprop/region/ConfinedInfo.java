package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.jvm.StackFrame;


/**
 * Interface for objects holding information about confined constructs. 
 */
public interface ConfinedInfo {

	ConfinedInfo deepCopy();

	/**
	 * Checks if the stack frame is in the confined context.
	 * 
	 * @param sf - stack frame to check.
	 * @return
	 */
	boolean isConfinedContext(StackFrame sf);

	boolean isEmpty();
	
	/**
	 * Returns a restriction information about the regions.
	 * @return
	 */
	RegionRestrictionInfo regionRestriction();
	
	/**
	 * Returns a restriction information about the classes.
	 * 
	 * @return
	 */
	ClassesRestrictionInfo classesRestriction();
	
	boolean isMethodConfined();
	boolean isTypeConfined();
	boolean isFieldConfined();
	boolean isConstructorConfined();
}
