package gov.nasa.jpf.aprop.region.util;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.annotation.ConfinedExecutable;
import gov.nasa.jpf.annotation.ConfinedField;
import gov.nasa.jpf.annotation.ConfinedType;
import gov.nasa.jpf.annotation.Region;
import gov.nasa.jpf.annotation.Self;
import gov.nasa.jpf.jvm.AnnotationInfo;
import gov.nasa.jpf.jvm.AnnotationInfo.Entry;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.FieldInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.MethodInfo;

/**
 * Reads reference constraints properties from JPF configuration.  
 */
public class RegionPropertiesReader {
	
	private static final String confinedType = "@ConfinedType";
	private static final String confinedField = "@ConfinedField";
	private static final String confinedExecutable = "@ConfinedExecutable";
	private static final String self = "@Self";
	private static final String region = "@Region";
	private static final String scopeParameter = "to";
	private static final String instanceParameter = "instance";
	private static final String typeParameter = "type";
	private static final String referenceParameter = "reference";
	private static final String valueParameter = "value";
	
	private Config config;
	
	private static RegionPropertiesReader instance;
	
	private RegionPropertiesReader(Config config) {
		this.config = config;
	}

	public static RegionPropertiesReader instance(JVM vm) {
		synchronized(RegionPropertiesReader.class) {
			if (instance == null) 
				instance = new RegionPropertiesReader(vm.getConfig());
		}
		return instance;
	}

	
	public void parse(ClassInfo ci) {
		String typeConfinement = config.getString(ci.getName());
		if (typeConfinement != null) {
			if (typeConfinement.contains(confinedType)) {			
				Entry scope = new Entry(scopeParameter, 
						parseArray(getParameterValue(scopeParameter, typeConfinement)));
				Entry instance = new Entry(instanceParameter, 
						Boolean.parseBoolean(getParameterValue(instanceParameter, typeConfinement)));
				Entry type = new Entry(typeParameter, 
						Boolean.parseBoolean(getParameterValue(instanceParameter, typeConfinement)));
				AnnotationInfo ai = new AnnotationInfo(ConfinedType.class.getCanonicalName(), 
						new Entry[] {scope, instance, type});
				ci.addAnnotation(ai);
			}
			if (typeConfinement.contains(region)) {
				Entry scope = new Entry(valueParameter, 
						parseArray(getParameterValue(scopeParameter, typeConfinement)));
				AnnotationInfo ai = new AnnotationInfo(Region.class.getCanonicalName(), 
						new Entry[] {scope});
				ci.addAnnotation(ai);
			}
		}
		for (FieldInfo fi : ci.getDeclaredInstanceFields()) {
			parse(fi);
		}
		for (FieldInfo fi : ci.getDeclaredStaticFields()) {
			parse(fi);
		}
		for (MethodInfo mi : ci.getDeclaredMethodInfos()) {
			parse(mi);
		}
	}
		
	private void parse(FieldInfo fi) {
		String fieldConfinement = config.getString(fi.getFullName());
		if (fieldConfinement != null) {
			if (fieldConfinement.contains(confinedField)) {
				Entry scope = new Entry(scopeParameter, 
						parseArray(getParameterValue(scopeParameter, fieldConfinement)));
				Entry reference = new Entry(referenceParameter, 
						Boolean.parseBoolean(getParameterValue(referenceParameter, fieldConfinement)));
				Entry value = new Entry(valueParameter, 
						Boolean.parseBoolean(getParameterValue(valueParameter, fieldConfinement)));
				AnnotationInfo ai = new AnnotationInfo(ConfinedField.class.getCanonicalName(), 
						new Entry[] {scope, reference, value});
				fi.addAnnotation(ai);
			} else if (fieldConfinement.contains(self)) {
				Entry reference = new Entry(referenceParameter, 
						Boolean.parseBoolean(getParameterValue(referenceParameter, fieldConfinement)));
				Entry value = new Entry(valueParameter, 
						Boolean.parseBoolean(getParameterValue(valueParameter, fieldConfinement)));
				fi.addAnnotation(new AnnotationInfo(Self.class.getCanonicalName(), new Entry[] {reference, value}));
			}
		}
	}
	
	private void parse(MethodInfo mi) {
		String methodConfinement = config.getString(mi.getFullName());
		if (methodConfinement != null && methodConfinement.contains(confinedExecutable)) {
			Entry scope = new Entry(valueParameter, 
					parseArray(getParameterValue(scopeParameter, methodConfinement)));
			mi.addAnnotation(new AnnotationInfo(ConfinedExecutable.class.getCanonicalName(), new Entry[] {scope}));
		}
	}

	private String[] parseArray(String parameterValue) {
		return parameterValue.split(",");
	}

	private String getParameterValue(String key, String txt) {
		int valueStartPosition = txt.indexOf(key) + key.length();
		int valueEndPosition = txt.indexOf(';', valueStartPosition) != -1 ? txt.indexOf(';', valueStartPosition) : txt.indexOf(')', valueStartPosition);
		txt = txt.substring(valueStartPosition, valueEndPosition).trim(); // from @ConfinedField( to = "value" we get = "value"
		txt = txt.substring(1).trim(); // we remove '=' character and trim the string again
		return txt;
	}	
	
}
