package gov.nasa.jpf.aprop.region;

/**
 * Utils putting invoking classes into dynamic regions. Native methods are
 * executed by the peer - JPF_gov_nasa_jpf_aprop_region_DynamicRegion.
 */
public class DynamicRegion {
	
	public native static void enterRegion(String regionName);
	
	public native static void endRegion(String regionName);
	
	public native static boolean amIInDynamicRegion();
}
