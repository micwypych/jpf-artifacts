package gov.nasa.jpf.aprop.region;

/**
 * A default implementation of the confined info for fields.
 */
public class DefaultConfinedFieldInfo extends DefaultConfinedInfo implements ConfinedFieldInfo {

	private static final ConfinedFieldInfo empty = new DefaultConfinedFieldInfo(new RegionRestrictionInfo(), 
			new ClassesRestrictionInfo(), true, true) {

				@Override
				public boolean reference() {
					return true;
				}

				@Override
				public boolean value() {
					return true;
				}

				@Override
				public boolean isEmpty() {
					return true;
				}
		
	};
	private boolean reference;
	private boolean value;
	
	public DefaultConfinedFieldInfo(RegionRestrictionInfo regionRestriction,
			ClassesRestrictionInfo classesRestriction,
			boolean reference, boolean value) {
		super(regionRestriction, classesRestriction);
		this.reference = reference;
		this.value = value;
	}

	@Override
	public boolean reference() {
		return reference;
	}

	@Override
	public boolean value() {
		return value;
	}

	@Override
	public boolean isFieldConfined() {
		return true;
	}	

	public static ConfinedFieldInfo emptyConfinedInfo() {
		return empty;
	}

	@Override
	public boolean isSelf() {
		return false;
	}
	
}
