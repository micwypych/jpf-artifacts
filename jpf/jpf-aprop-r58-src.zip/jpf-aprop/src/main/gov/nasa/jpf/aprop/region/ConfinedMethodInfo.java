package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.jvm.MethodInfo;

/**
 * Interface for objects holding information about confined methods.
 *
 */
public interface ConfinedMethodInfo extends ConfinedInfo  {

	boolean isConfinedMethodCall(MethodInfo invokingMethodInfo);

}
