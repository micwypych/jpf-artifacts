package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.ContractViolationFacade;
import gov.nasa.jpf.aprop.checker.GetInstructionChecker.GetViolationAttribute;
import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.ArrayStoreInstruction;

public class ArrayStoreInstructionChecker implements VMChecker {

	@Override
	public void check(JVM vm) {
		ElementInfo ei = vm.getLastElementInfo();
		StackFrame sf = vm.getLastThreadInfo().getTopFrame();
		GetViolationAttribute violationAttr = sf.getLocalAttr(0, GetViolationAttribute.class);
		ArrayStoreInstruction instruction = (ArrayStoreInstruction) vm.getLastInstruction();
		if (violationAttr != null) {
			if (ei.getObjectRef() == violationAttr.getObjectRef()) {
				ContractViolationFacade.throwConfinedFieldViolation(ThreadInfo.getCurrentThread(), 
						violationAttr.getInstruction(), sf.getMethodInfo());
			}
		}
	}

}
