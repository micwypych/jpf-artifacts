package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.jvm.StackFrame;

/**
 * A default implementation of the confined info. Base for further extensions of the ConfinedInfo.  
 */
public class DefaultConfinedInfo implements ConfinedInfo {

	private RegionRestrictionInfo regionRestriction;
	private ClassesRestrictionInfo classesRestriction;	
	
	private static final ConfinedInfo emptyInfo = new DefaultConfinedInfo(new RegionRestrictionInfo(), new ClassesRestrictionInfo()) {
		@Override
		public boolean isEmpty() {
			return true;
		}
	};	
	
	public DefaultConfinedInfo(RegionRestrictionInfo regionRestriction,
			ClassesRestrictionInfo classesRestriction) {
		super();
		this.regionRestriction = regionRestriction;
		this.classesRestriction = classesRestriction;
	}

	@Override
	public ConfinedInfo deepCopy() {
		return new DefaultConfinedInfo(
				(RegionRestrictionInfo) regionRestriction.deepCopy(),
				(ClassesRestrictionInfo) classesRestriction.deepCopy());
	}

	@Override
	public boolean isConfinedContext(StackFrame sf) {
		boolean result = this.classesRestriction.allowsUsage(sf.getMethodInfo().getClassName());
		if (!result) 
			result = this.regionRestriction.allowsUsage(sf.getMethodInfo());
		return result;
	}

	@Override
	public boolean isEmpty() {
		if (!regionRestriction.isEmpty() || !classesRestriction.isEmpty())
			return false;
		return true;
	}

	@Override
	public RegionRestrictionInfo regionRestriction() {
		return regionRestriction;
	}

	@Override
	public ClassesRestrictionInfo classesRestriction() {
		return classesRestriction;
	}
	
	public static ConfinedInfo emptyConfinedInfo() {
		return emptyInfo;
	}

	@Override
	public boolean isMethodConfined() {
		return false;
	}

	@Override
	public boolean isTypeConfined() {
		return false;
	}

	@Override
	public boolean isFieldConfined() {
		return false;
	}

	@Override
	public boolean isConstructorConfined() {
		return false;
	}

}
