package gov.nasa.jpf.aprop.region;

public interface SelfConfinedFieldInfo extends ConfinedFieldInfo {

	void setOwnerReference(int this1);

}
