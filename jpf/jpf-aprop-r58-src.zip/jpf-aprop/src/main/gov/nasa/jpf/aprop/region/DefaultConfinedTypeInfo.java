package gov.nasa.jpf.aprop.region;

/**
 * Default implementation of class for objects holding data about 
 * a type confinement.
 */
public class DefaultConfinedTypeInfo extends DefaultConfinedInfo implements ConfinedTypeInfo {

	private boolean instance;
	private boolean type;
	
	private static final ConfinedTypeInfo empty = new DefaultConfinedTypeInfo(new RegionRestrictionInfo(), new ClassesRestrictionInfo(), true, true) {

		@Override
		public boolean isEmpty() {
			return true;
		}
		
	};
	
	public DefaultConfinedTypeInfo(RegionRestrictionInfo regionRestriction,
			ClassesRestrictionInfo classesRestriction, boolean instance, boolean type) {
		super(regionRestriction, classesRestriction);
		this.instance = instance;
		this.type = type;
	}

	@Override
	public boolean instance() {
		return instance;
	}

	@Override
	public boolean type() {
		return type;
	}
	
	@Override
	public boolean isTypeConfined() {
		return true;
	}

	public static ConfinedTypeInfo emptyConfinedInfo() {
		return empty;
	}

}
