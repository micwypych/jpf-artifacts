//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.region.ConfinedInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfoContainer;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.ExceptionHandler;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.MethodInfo;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;

import java.util.Iterator;

/**
 * Checker for exception thrown notification. 
 */
public class ThrowExceptionChecker implements VMChecker {

	@Override
	public void check(JVM vm) {
		ElementInfo ei = vm.getLastElementInfo();
		ConfinedInfo confinedInfo = ConfinedInfoContainer.instance().forClass(ei.getClassInfo());
		if (!confinedInfo.isEmpty()) {
			ThreadInfo ti = vm.getLastThreadInfo();
			Iterator<StackFrame> sfIterator = ti.iterator();
			while (sfIterator.hasNext()) {
				StackFrame sf = sfIterator.next();
				if (hasException(sf.getMethodInfo(), ei.getClassInfo()) && !confinedInfo.isConfinedContext(sf)) {
					sf.setLocalAttr(0, 
							new ThrowViolationAttribute(ei.getObjectRef(), ti.getTopFrame().getMethodInfo(), ei.getClassInfo()));
					break;
				}
			} 
		}
	}
	
	/**
	 * Returns true if the method contains an exception handler for 
	 * the given exception type. 
	 * 
	 * @param methodInfo
	 * @param exception
	 * @return
	 */
	private boolean hasException(MethodInfo methodInfo, ClassInfo exception) {
		if (methodInfo.getExceptions() == null)
			return false;
		for (ExceptionHandler handler : methodInfo.getExceptions()) {
			if (exception.getSuperClass(handler.getName()) != null) {
				return true;
			}
		}
		return false;
	}

}
