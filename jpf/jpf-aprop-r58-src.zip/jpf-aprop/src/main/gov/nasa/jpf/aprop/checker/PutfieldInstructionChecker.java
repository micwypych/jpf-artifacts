package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.jvm.bytecode.FieldInstruction;
import gov.nasa.jpf.jvm.bytecode.PUTFIELD;

public class PutfieldInstructionChecker extends FieldStoreInstructionChecker {

	@Override
	protected <T extends FieldInstruction> int getObjectRef(T instruction) {
		return (int) ((PUTFIELD) instruction).getLastValue();
	}

	@Override
	protected <T extends FieldInstruction> int getThis(T instruction) {
		return (int) ((PUTFIELD) instruction).getLastThis();
	}
	
}
