package gov.nasa.jpf.aprop.region;

/**
 * Interface for objects holding information about confined types. 
 */
public interface ConfinedTypeInfo extends ConfinedInfo {

	/**
	 * Returns true if instance members of the type are
	 * confined to specified scope. 
	 * 
	 * @return
	 */
	boolean instance();
	
	/**
	 * Returns true if both: static and instance members of the
	 * type are confined to specified scope. 
	 * 
	 * @return
	 */
	boolean type();
	
}
