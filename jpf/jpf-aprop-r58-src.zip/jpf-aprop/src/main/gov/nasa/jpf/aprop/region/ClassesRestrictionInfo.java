//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region;

import gov.nasa.jpf.aprop.exception.ConfinedException;
import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.NoClassInfoException;

/**
 * Encapsulation of confined classes restriction. 
 */
public class ClassesRestrictionInfo extends AbstractRestrictionInfo {

	public static final String EXTENDS_PATTERN = "? extends ";
	
	private static final class IllegalConfinedClassPattern extends ConfinedException {
		private static final long serialVersionUID = 5140940771049743423L;

		public IllegalConfinedClassPattern(String message) {
			super(message);
		}
		
	}
	
	private String self;
	
	/**
	 * Regexp pattern of java class.
	 */
	private static final String JAVA_CLASS_PATTERN = 
		"^(([a-zA-Z][a-zA-Z_$0-9]*(\\.[a-zA-Z][a-zA-Z_$0-9]*)*)\\.)?([a-zA-Z][a-zA-Z_$0-9]*)$";
	
	public ClassesRestrictionInfo() {
		super();
	}
	
	public ClassesRestrictionInfo(ClassesRestrictionInfo x, ClassesRestrictionInfo y) {
		super(x,y);
	}
	
	@Override
	public void addConfinee(String className) {
		validateClassName(className);
		value.add(className);
	}

	private boolean matchesClassRegexp(String className) {
		return className.matches(JAVA_CLASS_PATTERN); 
	}
	
	private void validateClassName(String className) {
		boolean illegalClassName = false;
		if (className.startsWith("?")) {
			illegalClassName = !matchesClassRegexp(stripExtendsSuffix(className));
		} else if (className.endsWith("*")) {
			illegalClassName = !matchesClassRegexp(stripPackageSuffix(className));
		} else if (!matchesClassRegexp(className)) {
			illegalClassName = true;
		}
		if (illegalClassName)
			throw new IllegalConfinedClassPattern("Illegal class pattern " + className);
	}

	@Override
	public boolean allowsUsage(String caller) {
		ClassInfo callerClassInfo = null;
		try {
			callerClassInfo = ClassInfo.getResolvedClassInfo(caller);
		} catch (NoClassInfoException nci) {
			return false;			
		}		
		if (allowsUsage(callerClassInfo, self))
			return true;
		for (String s : value) {
			if (allowsUsage(callerClassInfo, s)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns true if the given parameter is on a list
	 * of confined classes.
	 * 
	 * @param callerClassInfo - tested type.
	 * @param confinee - confined type. 
	 * @return
	 */
	private boolean allowsUsage(ClassInfo callerClassInfo, String confinee) {
		return (confinee.endsWith("*") && isCallerInPackage(callerClassInfo, stripPackageSuffix(confinee))
				|| isInner(callerClassInfo, confinee)
				||	(confinee.startsWith("?") && isCallerSubclass(callerClassInfo, stripExtendsSuffix(confinee)))
				|| confinee.equals(callerClassInfo.getName()));
	}
	
	private boolean isInner(ClassInfo callerClassInfo, String confinee) {
		return callerClassInfo.getName().startsWith(confinee);
	}

	private boolean isCallerInPackage(ClassInfo callerClassInfo, String packageName) {
		return callerClassInfo.getPackageName().startsWith(packageName);
	}
	
	private boolean isCallerSubclass(ClassInfo calllerClassInfo, String caller) {
		if (caller.contains(EXTENDS_PATTERN)) {
			return calllerClassInfo.getSuperClass(stripExtendsSuffix(caller)) != null;
		}
		return false;
	}

	@Override
	public AbstractRestrictionInfo deepCopy() {
		ClassesRestrictionInfo cri = new ClassesRestrictionInfo();
		for (String s : value) {
			cri.value.add(new String(s));
		}
		return cri;
	}

	/**
	 * Class narrowing is legal in the following situations:
	 * 	- class extends another class specified with formula ? extends canonicalClassName
	 * 	- class is in the package specified with formula package.name
	 * 	- is inner class of class/package on the class list 
	 * 
	 * @param existing
	 * @param narrower
	 * @return
	 */
	@Override
	protected boolean narrows(String existing, String narrower) {
		try {
			ClassInfo classInfo = ClassInfo.getResolvedClassInfo(narrower);
			if (existing.endsWith("*")) {
				return classInfo.getPackageName().startsWith(stripPackageSuffix(existing));
			} else if (existing.startsWith("?")) {
				return classInfo.getSuperClass(stripExtendsSuffix(existing)) != null;				
			} else {
				return existing.startsWith(classInfo.getName());
			}
		} catch (NoClassInfoException nci) {
			return false;			
		}
	}

	@Override
	protected boolean isEmpty() {
		return value.isEmpty();
	}

	@Override
	public String toString() {
		return "ClassesRestrictionInfo [value=" + value + "]";
	}	
	
	public String stripPackageSuffix(String packageName) {
		return packageName.substring(0, packageName.length() - 2);
	}
	
	public String stripExtendsSuffix(String extendsClassName) {
		if (!extendsClassName.contains(EXTENDS_PATTERN)) {
			throw new IllegalConfinedClassPattern("Illegal ? extends className " + extendsClassName);
		}
		return extendsClassName.substring(EXTENDS_PATTERN.length()).trim();
	}

	public String getSelf() {
		return self;
	}

	public void setSelf(String self) {
		this.self = self;
	}

	@Override
	protected String stripPrefix(String value) {
		return value;
	}

	public static ClassesRestrictionInfo intersection(
			ClassesRestrictionInfo inner,
			ClassesRestrictionInfo outer) {
		ClassesRestrictionInfo info = new ClassesRestrictionInfo();
		for (String x : inner.value) {
			if (outer.value.contains(x))
				info.value.add(x);
		}
		return info;
	}
}
