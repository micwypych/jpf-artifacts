//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.ContractViolationFacade;
import gov.nasa.jpf.aprop.region.ConfinedInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfoContainer;
import gov.nasa.jpf.aprop.region.ConfinedMethodInfo;
import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.MethodInfo;
import gov.nasa.jpf.jvm.bytecode.InvokeInstruction;

/**
 * Checker for invoke method. 
 * 
 * @see gov.nasa.jpf.jvm.bytecode.InvokeInstruction
 */
public class InvokeInstructionChecker implements VMChecker {

	@Override
	public void check(JVM vm) {
		InvokeInstruction invokeInstruction = (InvokeInstruction) vm.getLastInstruction();
		MethodInfo invokedMethodInfo = invokeInstruction.getInvokedMethod();
		MethodInfo invokingMethodInfo = invokeInstruction.getMethodInfo();
		ElementInfo ei = vm.getLastElementInfo();
		ConfinedInfo ci = ConfinedInfoContainer.instance().method(invokedMethodInfo);
		if (!invokedMethodInfo.isMJI() && violation(ei, ci, invokingMethodInfo)) {
			ContractViolationFacade.throwConfinedMethodViolation(vm.getLastThreadInfo(), 
					invokedMethodInfo, invokingMethodInfo);
		}
	}
	
	private boolean violation(ElementInfo ei, ConfinedInfo ci, MethodInfo invokingMethodInfo) {
		if (!ci.isEmpty() && ci instanceof ConfinedMethodInfo && !((ConfinedMethodInfo)ci).isConfinedMethodCall(invokingMethodInfo)) {
			return true;
		}
		if (ei == null)
			return false;
		/*EarlyRegionEndViolationAttribute violationAttribute = ei.getObjectAttr(EarlyRegionEndViolationAttribute.class);
		if (violationAttribute != null && 
				!violationAttribute.getConfinedInfo().isConfinedMethodCall(invokingMethodInfo)) {
			return true;
		} */
		return false;
	}

}
