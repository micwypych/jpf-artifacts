package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.region.ConfinedFieldInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfoContainer;
import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.JVM;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.FieldInstruction;

import java.util.Iterator;

/**
 * <p>Checks violation on GETFIELD and GETSTATIC.</p> 
 * <p>Unlike PUTFIELD or PUTSTATIC checking for a get violation
 * does not happen in place. When a get method is invoked stack
 * frame does not know about the operand which is return.
 * 
 * someMethod() {
 *  // at this point result of getMethod is not on list
 *  // of someMethod operands
 *  a.getMethod // at this point there is a new operand
 *  // on someMethod list of operands
 * }
 * 
 * So, GetInstructionChecker persists an information about
 * a possible violation of the Confined to the stack frame. 
 * The violation itself is checker by ReturnInstructionChecker.
 *  </p>
 * 
 * 
 * @see gov.nasa.jpf.jvm.bytecode.GETFIELD
 * @see gov.nasa.jpf.jvm.bytecode.GETSTATIC
 */
public abstract class GetInstructionChecker implements VMChecker {

	public static class GetViolationAttribute extends AbstractViolationAttribute {
		private FieldInstruction instruction;
		private ConfinedFieldInfo confinedFieldInfo;
		
		public GetViolationAttribute(int objectRef, FieldInstruction instruction, ConfinedFieldInfo ci) {
			super(objectRef);
			this.instruction = instruction;
			this.confinedFieldInfo = ci;
		}

		public FieldInstruction getInstruction() {
			return instruction;
		}

		public ConfinedFieldInfo getConfinedFieldInfo() {
			return confinedFieldInfo;
		}		
	}
	
	@Override
	public void check(JVM vm) {
		FieldInstruction fieldInstruction = (FieldInstruction) vm.getLastInstruction();
		ConfinedInfo confinedInfo = ConfinedInfoContainer.instance().field(fieldInstruction.getFieldInfo());
		if (!confinedInfo.isEmpty()) {		
			ThreadInfo ti = ThreadInfo.getCurrentThread();
			ElementInfo ei = getElementInfo(fieldInstruction, ti);
			int objectRef = ei.getObjectRef();
			Iterator<StackFrame> sfIterator = ThreadInfo.getCurrentThread().iterator();
			while (sfIterator.hasNext()) {				
				StackFrame sf = sfIterator.next();
				if (isVerifiable(sf) && !confinedInfo.isConfinedContext(sf)) {
					sf.setLocalAttr(0, new GetViolationAttribute(objectRef, fieldInstruction, (ConfinedFieldInfo) confinedInfo));
					ei.setObjectAttr(new EarlyRegionEndViolationAttribute(objectRef, fieldInstruction, sf.getMethodInfo(), confinedInfo));
					break;
				}				
			} 
		}		
	}
	
	protected abstract ElementInfo getElementInfo(FieldInstruction instruction, ThreadInfo ti);
	
	/**
	 * Determines whether the given StackFrame is a part 
	 * of application to verify. 
	 * 
	 * @param sf
	 * @return
	 */
	private boolean isVerifiable(StackFrame sf) {
		return !sf.getMethodInfo().isMJI() && !sf.getMethodInfo().isReflectionCallStub();
	}

}
