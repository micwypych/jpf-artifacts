package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.aprop.checker.GetInstructionChecker.GetViolationAttribute;
import gov.nasa.jpf.aprop.region.ConfinedFieldInfo;
import gov.nasa.jpf.aprop.region.ConfinedInfo;
import gov.nasa.jpf.jvm.MethodInfo;
import gov.nasa.jpf.jvm.bytecode.FieldInstruction;

/**
 * Element info attribute necessary for violation checks when caller could have
 * left dynamic region.
 * 
 * Example:
 * 	DynamicRegion.enterRegion("secret");
 * 	Date d = getSomeConfinedDate();
 * 	DynamicRegion.endRegion("secret");
 * 	d.setTime(123456); <-- violation
 */
public class EarlyRegionEndViolationAttribute extends GetViolationAttribute {

	private MethodInfo methodInfo;
	private ConfinedInfo confinedInfo;
	
	protected EarlyRegionEndViolationAttribute(int objectRef, FieldInstruction instruction, 
			MethodInfo methodInfo, ConfinedInfo confinedInfo) {
		super(objectRef, instruction, (ConfinedFieldInfo) confinedInfo);
		this.methodInfo = methodInfo;
		this.confinedInfo = confinedInfo;
	}

	public MethodInfo getMethodInfo() {
		return methodInfo;
	}

	public ConfinedInfo getConfinedInfo() {
		return confinedInfo;
	}
	
	public void setObjectRef(int objectRef) {
		super.setObjectRef(objectRef);
	}
}
