package gov.nasa.jpf.aprop.checker;

import gov.nasa.jpf.jvm.ElementInfo;
import gov.nasa.jpf.jvm.StackFrame;
import gov.nasa.jpf.jvm.ThreadInfo;
import gov.nasa.jpf.jvm.bytecode.FieldInstruction;

public class GetFieldInstructionChecker extends GetInstructionChecker {

	@Override
	protected ElementInfo getElementInfo(FieldInstruction instruction,
			ThreadInfo ti) {
		int objectReference = objectReference(ti);
		return ti.getElementInfo(objectReference);
	}
	
	private int objectReference(ThreadInfo ti) {
		int peek = ti.peek();
		StackFrame topFrame = ti.getTopFrame();
		if (peek == -1)
			peek = ti.peek(1);
		return peek;
	}
	
}
