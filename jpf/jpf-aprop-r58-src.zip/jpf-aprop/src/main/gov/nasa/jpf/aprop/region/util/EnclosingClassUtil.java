//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.aprop.region.util;

import gov.nasa.jpf.jvm.ClassInfo;
import gov.nasa.jpf.jvm.NoClassInfoException;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class extending ClassInfo with methods related to enclosing classes.
 */
public class EnclosingClassUtil {

	/*
	 * bcel does not provide API which can be used by the following methods.
	 */
	
	/**
	 * Checks if class is inner class.
	 * 
	 * @param ci - class info of class which has to be checked.
	 * @return - true if class is an inner class
	 */
	public boolean isInnerClass(ClassInfo ci) {
		return isInnerClass(ci.getName());
	}
	
	/**
	 * Checks if class is inner class.
	 * 
	 * @param className - canonical name of class which has to be checked.
	 * @return - true if class is an inner class
	 */
	private boolean isInnerClass(String className) {
		if (className.contains("$")) { // might be an inner class
			String potentialOuterClassName = className.substring(0, className.indexOf("$"));
			try {
				ClassInfo.getResolvedClassInfo(potentialOuterClassName);
				return true;
			} catch (NoClassInfoException ncie) {
				return false;
			}
		}
		return false;
	}
	
	/**
	 * Returns list of classes enclosing given class.
	 * 
	 * @param ci - class info
	 * @return - list of classes enclosing class info from parameter
	 */
	public List<ClassInfo> getEnclosingClasses(ClassInfo ci) {
		if (!isInnerClass(ci)) 
			return new ArrayList<ClassInfo>();
		List<ClassInfo> classes = new ArrayList<ClassInfo>();
		String className = ci.getName();
		String potentialOuterClassname = "";
		while (className.contains("$")) {
			potentialOuterClassname += className.substring(0, className.indexOf("$"));
			className = className.substring(className.indexOf("$") + 1);
			try {
				ClassInfo enclosingClass = ClassInfo.getResolvedClassInfo(potentialOuterClassname);
				classes.add(enclosingClass);
			} catch (NoClassInfoException ncie) {
			}
		}
		return classes;
	}
	
}
