package gov.nasa.jpf.test.aprop.region;

import gov.nasa.jpf.annotation.ConfinedField;
import gov.nasa.jpf.util.test.TestJPF;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.Test;

public class ConfinedReflection extends TestJPF {

	static final String[] JPF_ARGS = { "+listener=.aprop.listener.ConfinedChecker" };
	
	public static void main(String... args) throws Exception {
		runTestsOfThisClass(args);	
	}
	
	public static class Holdee {
		private int value;

		public int getValue() {
			return value;
		}
		public void setValue(int value) {
			this.value = value;
		}		
	}
	
	public static class ConfinedHolder {
		@ConfinedField(to = "gov.nasa.jpf.test.aprop.region.ConfinedReflection$ConfinedLegal", reference = false, value = true)
		private Holdee valueHoldee;	
		
		@ConfinedField(to = "gov.nasa.jpf.test.aprop.region.ConfinedReflection$ConfinedLegal", reference = true, value = false)
		private Holdee referenceHoldee;	
		
		// @ConfinedField(to = "gov.nasa.jpf.test.aprop.region.ConfinedReflection$ConfinedLegal", reference = true, value = true)
		private Holdee[] holdees;
		
		public ConfinedHolder() {
			this.valueHoldee = new Holdee();
			this.referenceHoldee = new Holdee();
			this.holdees = new Holdee[10];
		}
		public Holdee getValueHoldee() {
			return valueHoldee;
		}
		public void setValueHoldee(Holdee holdee) {
			this.valueHoldee = holdee;
		}
		public Holdee getReferenceHoldee() {
			return referenceHoldee;
		}
		public void setReferenceHoldee(Holdee referenceHoldee) {
			this.referenceHoldee = referenceHoldee;
		}		
		public Holdee[] getHoldees() {
			return holdees;
		}
		public void putHoldee(int index, Holdee holdee) {
			holdees[index] = holdee;
		}
		
	}
	
	public static class ConfinedBreaker {
		private ConfinedHolder holder;
		public ConfinedBreaker() {
			this.holder = new ConfinedHolder();
		}
		// illegal - putfield on confined object
		public void breakConfinedByChangingValue() throws Exception {
			Method m = Holdee.class.getDeclaredMethod("setValue", int.class);
			m.invoke(holder.getValueHoldee(), 2);
		}

		public void breakConfinedReference() throws Exception {
			Method m = Holdee.class.getDeclaredMethod("getValue", new Class[0]);
			m.invoke(holder.getValueHoldee(), new Object[0]);			
		}
		
		public void breakByPuttingHoldee() throws Exception {
			Method m = ConfinedHolder.class.getDeclaredMethod("getHoldees", new Class[0]);
			Holdee[] array = (Holdee[]) m.invoke(holder, new Object[0]);
			array[1] = new Holdee();
		}
	}
	public static class ConfinedLegal {
		private ConfinedHolder holder;
		public ConfinedLegal() {
			this.holder = new ConfinedHolder();
		}
		// legal - putfield on confined object, but Confined is allowed to do that
		public void legallyChangeConfinedValue() throws Exception {
			Method m = Holdee.class.getDeclaredMethod("setValue", int.class);
			m.invoke(holder.getValueHoldee(), 2);
		}
		// legal
		public void legallyGetTheReference() throws Exception {
			Method m = Holdee.class.getDeclaredMethod("getValue", new Class[0]);
			m.invoke(holder.getValueHoldee(), new Object[0]);
		}	
		public void legallyChangeTheConfinedRefReference() {
			holder.setReferenceHoldee(new Holdee());
		}
		public void legallyChangeTheConfinedRefValue() {
			holder.getReferenceHoldee().setValue(2);
		}
	}
	
	@Test
	public void breakConfinedValueWithReflection() throws Exception {
		if (verifyAssertionError(JPF_ARGS)) {
			new ConfinedBreaker().breakConfinedByChangingValue();
		}
	}
	
	@Test
	public void donotBreakConfinedValueWithReflection() throws Exception {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ConfinedLegal().legallyChangeConfinedValue();
		}
	}
	
	@Test
	public void breakConfinedReferenceWithReflection() throws Exception {
		if (verifyAssertionError(JPF_ARGS)) {
			new ConfinedBreaker().breakConfinedReference();			
		}
	}
	
	@Test
	public void donotBreakConfinedReferenceWithReflection() throws Exception {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ConfinedLegal().legallyGetTheReference();			
		}
	}
	
	@Test
	public void breakByPuttingNewHoldeeIntoArray() throws Exception {
		if (verifyAssertionError(JPF_ARGS)) {
			new ConfinedBreaker().breakByPuttingHoldee();
		}
	}
}
