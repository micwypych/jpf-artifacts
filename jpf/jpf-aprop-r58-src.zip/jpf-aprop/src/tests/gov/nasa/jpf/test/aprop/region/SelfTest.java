package gov.nasa.jpf.test.aprop.region;

import gov.nasa.jpf.annotation.Self;
import gov.nasa.jpf.util.test.TestJPF;

import java.util.Date;

import org.junit.Test;

public class SelfTest extends TestJPF {

	static final String[] JPF_ARGS = { "+listener=.aprop.listener.ConfinedChecker" };
	
	public static void main(String... args) {
		runTestsOfThisClass(args);	
	}
	
	public static class SelfHolder {
		@Self(reference = true)
		private Date a;

		public Date getA() {
			return a;
		}

		public void setA(Date a) {
			this.a = a;
		}
		public void setItItself() {
			this.a = new Date();
		}
		public void changeItItself() {
			a.setTime(2);
		}
		
	}
	
	public static class SelfBreaker {

		public void breakSelf() {
			new SelfHolder().a = new Date();
		}
		public void breakSelfWithSetter() {
			new SelfHolder().setA(new Date());
		}
		public void breakValue() {
			new SelfHolder().getA().setTime(123);
		}
	}
	
	@Test
	public void breakSelfWithReference() {
		if (verifyAssertionError(JPF_ARGS))
			new SelfBreaker().breakSelf();
	}
	
	@Test
	public void breakSelfWithSetter() {
		if (verifyAssertionError(JPF_ARGS)) {
			new SelfBreaker().breakSelfWithSetter();
		}
	}
	
	@Test
	public void dontBreakSelfWithReferenceChange() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new SelfHolder().setItItself();
		}
	} 
	
	@Test
	public void breakSelfValueWithGetter() {
		if (verifyAssertionError(JPF_ARGS)) {
			new SelfBreaker().breakValue();
		}
	}
	
	@Test
	public void dontBreakSelfWithValueChange() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new SelfHolder().setItItself();
		}
	}
}
