package gov.nasa.jpf.test.aprop.region;

import gov.nasa.jpf.annotation.ConfinedType;
import gov.nasa.jpf.util.test.TestJPF;

import org.junit.Test;

public class ConfinedTypeTest extends TestJPF {

	static final String[] JPF_ARGS = { "+listener=.aprop.listener.ConfinedChecker" };
	
	public static void main(String... args) {
		runTestsOfThisClass(args);	
	}
	public static class Holdee {
		private int value;

		public int getValue() {
			return value;
		}
		public void setValue(int value) {
			this.value = value;
		}		
	}
	
	// @ConfinedType(instance = true, type = true, to = "gov.nasa.jpf.test.aprop.region.ConfinedTypeTest$ConfinedLegal")
	public static class ConfinedHolder {
		private Holdee valueHoldee;	
		private Holdee referenceHoldee;	
		
		
		public ConfinedHolder() {
			this.valueHoldee = new Holdee();
			this.referenceHoldee = new Holdee();
		}
		public Holdee getValueHoldee() {
			return valueHoldee;
		}
		public void setValueHoldee(Holdee holdee) {
			this.valueHoldee = holdee;
		}
		public Holdee getReferenceHoldee() {
			return referenceHoldee;
		}
		public void setReferenceHoldee(Holdee referenceHoldee) {
			this.referenceHoldee = referenceHoldee;
		}		
		
	}
	
	public static class ConfinedBreaker {
		private ConfinedHolder holder;
		public ConfinedBreaker() {
			this.holder = new ConfinedHolder();
		}
		// illegal - putfield on confined object
		public void breakConfinedByChangingValue() {
			holder.getValueHoldee().setValue(2);
		}
		// legal, holdee's value is Confined, not a reference
		public void legallyChangeTheReference() {
			holder.setValueHoldee(new Holdee());
		}
		public void breakConfinedByChangingReference() {
			holder.setReferenceHoldee(new Holdee());
		}
		public void legallyChangeTheConfinedValue() {
			holder.getReferenceHoldee().setValue(3);
		}
	}
	public static class ConfinedLegal {
		private ConfinedHolder holder;
		public ConfinedLegal() {
			this.holder = new ConfinedHolder();
		}
		// legal - putfield on confined object, but Confined is allowed to do that
		public void legallyChangeConfinedValue() {
			holder.getValueHoldee().setValue(2);
		}
		// legal
		public void legallyChangeTheReference() {
			holder.setValueHoldee(new Holdee());
		}	
		public void legallyChangeTheConfinedRefReference() {
			holder.setReferenceHoldee(new Holdee());
		}
		public void legallyChangeTheConfinedRefValue() {
			holder.getReferenceHoldee().setValue(2);
		}
	}	
	
	@Test
	public void breakConfinedValue_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			ConfinedBreaker cb = new ConfinedBreaker();
			cb.breakConfinedByChangingValue();
		}
	} 
	
	@Test
	public void breakConfinedReference_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			ConfinedBreaker cb = new ConfinedBreaker();
			cb.breakConfinedByChangingReference();
		}
	}
	
	@Test
	public void changeTheValueOfConfinedRef_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			ConfinedLegal cl = new ConfinedLegal();
			cl.legallyChangeConfinedValue();
		}
	}
}
