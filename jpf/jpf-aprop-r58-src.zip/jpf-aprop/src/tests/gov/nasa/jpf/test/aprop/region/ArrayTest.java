//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.jpf.test.aprop.region;

import gov.nasa.jpf.annotation.ConfinedField;
import gov.nasa.jpf.aprop.region.DynamicRegion;
import gov.nasa.jpf.util.test.TestJPF;

import org.junit.Test;

/**
 * Regression tests for handling confined arrays. 
 */
public class ArrayTest extends TestJPF {

	static final String[] JPF_ARGS = { "+listener=.aprop.listener.ConfinedChecker;.aprop.region.RegionsChecker;.aprop.region.DynamicRegionListener" };
	
	public static void main(String... args) {
		runTestsOfThisClass(args);	
	}
	
	static class Y {
		long date;
	}
	
	static class X {
		@ConfinedField(reference = true, value = true, to = "#secret.d")
		int[] array;
		
		@ConfinedField(reference = true, value = true, to = "#secret")
		Y[] y;
		
		@ConfinedField(reference = true, value = true, to = "#secret")
		Y z;
		
		public int[] getArray() {
			return array;
		}

		public void setArray(int[] array) {
			this.array = array;
		}

		public Y[] getY() {
			return y;
		}

		public void setY(Y[] y) {
			this.y = y;
		}

		public Y getZ() {
			return z;
		}

		public void setZ(Y z) {
			this.z = z;
		}
	}
	
	@Test
	public void newPrimitiveArray_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			X x = new X();
			x.array = new int[20];
		}
	}
	
	@Test
	public void newPrimitiveArray_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.array = new int[20];
			DynamicRegion.endRegion("secret");
		}
	}
	
	@Test
	public void storePrimitiveInConfinedArray_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.array = new int[20];
			DynamicRegion.endRegion("secret");
			x.array[5] = 5;
		}
	}
	
	@Test
	public void storePrimitiveInConfnedArray_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.array = new int[20];
			x.array[5] = 5;
			DynamicRegion.endRegion("secret");
		}	
	} 
	
	@Test
	public void storePrimitiveInConfnedArrayWithMethod_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			int[] a = new int[20];
			x.setArray(a);
			DynamicRegion.endRegion("secret");
		}	
	}
	
	@Test
	public void storePrimitiveInConfnedArrayWithMethod_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			X x = new X();
			int[] a = new int[20];
			x.setArray(a);
		}	
	}

	
	@Test
	public void getPrimitiveInConfnedArrayWithMethod_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			int[] a = new int[20];
			x.setArray(a);
			@SuppressWarnings("unused")
			int i = x.getArray()[5];
			DynamicRegion.endRegion("secret");
		}	
	}
	
	@Test
	public void getPrimitiveInConfnedArrayWithMethod_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			int[] a = new int[20];
			x.setArray(a);
			DynamicRegion.endRegion("secret");
			@SuppressWarnings("unused")
			int i = x.getArray()[4];
		}	
	}
	
	@Test
	public void newObjectArray_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			X x = new X();
			x.y = new Y[10];
		}
	}
	
	@Test
	public void newObjectArray_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.y = new Y[10];
			DynamicRegion.endRegion("secret");
		}
	}
	
	@Test
	public void newObjectArrayWithMetohd_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			X x = new X();
			x.setY(new Y[5]);
		}
	}
	
	@Test
	public void newObjectArrayWithMethod_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			DynamicRegion.endRegion("secret");
		}
	}
	
	@Test
	public void newArrayObject_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			DynamicRegion.endRegion("secret");
			x.y[2] = new Y();
		}
	}
	
	@Test
	public void newArrayObject_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			DynamicRegion.endRegion("secret");
		}
	}
	
	@Test
	public void getArrayObject_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			Y y = x.y[2];
			DynamicRegion.endRegion("secret");
		}
	} 
	
	@Test
	public void getArrayObjectWithMethod_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			DynamicRegion.endRegion("secret");
			Y y = x.getY()[2];
		}
	}
	
	@Test
	public void getArrayObjectWithMethod_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			Y y = x.getY()[2];
			DynamicRegion.endRegion("secret");
		}
	}

	@Test
	public void getArrayObject_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			DynamicRegion.endRegion("secret");
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			Y y = x.y[2];
		}
	}
	
	@Test
	public void getArrayObjectField_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			DynamicRegion.endRegion("secret");
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			long y = x.y[2].date;
		}
	}
	
	@Test
	public void getArrayObjectFieldWithMethod_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			DynamicRegion.endRegion("secret");
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			long y = x.getY()[2].date;
		}
	}
	
	@Test
	public void getArrayObjectField_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			long y = x.y[2].date;
			DynamicRegion.endRegion("secret");			
		}
	}
	
	@Test
	public void getArrayObjectFieldWithMethod_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			long y = x.getY()[2].date;
			DynamicRegion.endRegion("secret");
		}
	}
	
	@Test
	public void getArrayWithMethod_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			DynamicRegion.endRegion("secret");
			@SuppressWarnings("unused")
			Y[] ys = x.getY();
		}
	}
	
	@Test
	public void getArray_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			DynamicRegion.endRegion("secret");
			@SuppressWarnings("unused")
			Y[] ys = x.y;
		}
	}
	
	@Test
	public void getArrayWithMethod_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			Y[] ys = x.getY();
			DynamicRegion.endRegion("secret");
		}
	}
	
	@Test
	public void getArray_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			Y[] ys = x.y;
			DynamicRegion.endRegion("secret");
		}
	} 
	
	@Test
	public void getArrayPrimitiveTwice_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.setArray(new int[20]);
			x.y[2] = new Y();
			@SuppressWarnings("unused")
			int i = x.array[2];
			DynamicRegion.endRegion("secret");
			i = x.array[3];
		}
	}

	@Test
	public void getArrayObjectTwice_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			DynamicRegion.enterRegion("secret");
			X x = new X();
			x.setY(new Y[5]);
			x.setArray(new int[20]);
			x.y[2] = new Y();
			x.y[3] = new Y();
			@SuppressWarnings("unused")
			Y y = x.y[2];
			DynamicRegion.endRegion("secret");
			y = x.y[3];
		}
	} 
}
