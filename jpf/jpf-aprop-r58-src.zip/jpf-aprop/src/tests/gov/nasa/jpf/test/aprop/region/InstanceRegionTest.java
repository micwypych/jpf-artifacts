package gov.nasa.jpf.test.aprop.region;

import gov.nasa.jpf.annotation.InstanceRegion;
import gov.nasa.jpf.util.test.TestJPF;

import org.junit.Test;

/**
 * Regression tests of @InstanceRegion. 
 */
public class InstanceRegionTest extends TestJPF {

	static final String[] JPF_ARGS = { "+listener=.aprop.listener.InstanceRegionChecker" };
	
	public static void main(String... args) {
		runTestsOfThisClass(args);	
	}
	
	@InstanceRegion
	public static class UserRoles {
		
	}
	
	public static class User {
		private UserRoles roles;

		public User() {
			super();
			roles = new UserRoles();
		}

		public UserRoles getRoles() {
			return roles;
		}

		public void setRoles(UserRoles roles) {
			this.roles = roles;
		}				
	}
	
	@Test
	public void checkInstanceRegionViolation_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			User filip = new User();
			User suzette = new User();
			suzette.setRoles(filip.getRoles());
		}
	}
	
}
