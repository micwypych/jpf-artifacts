package gov.nasa.jpf.test.aprop.region;

import gov.nasa.jpf.annotation.ConfinedField;
import gov.nasa.jpf.util.test.TestJPF;

import org.junit.Test;

/**
 * Set of test cases checking @Confiend across many threads.
 */
public class ParallelConfinedTest extends TestJPF {

	static final String[] JPF_ARGS = { "+listener=.aprop.listener.ConfinedChecker" };
	
	public static void main(String... args) {
		runTestsOfThisClass(args);	
	}
	
	public static class Holdee {
		private int value;

		public int getValue() {
			return value;
		}

		public void setValue(int value) {
			this.value = value;
		}
		
	}
	
	public static class ConfinedHolder {
		@ConfinedField(to = "gov.nasa.jpf.test.aprop.region.ParallelConfinedTest$ParallelConfinedLegal", reference = false, value = true)
		private Holdee valueHoldee;	
		
		@ConfinedField(to = "gov.nasa.jpf.test.aprop.region.ParallelConfinedTest$ParallelConfinedLegal", reference = true, value = false)
		private Holdee referenceHoldee;
		
		public ConfinedHolder() {
			this.valueHoldee = new Holdee();
			this.referenceHoldee = new Holdee();			
		}
		
		public Holdee getValueHoldee() {			
			return valueHoldee;
		}
		public void setValueHoldee(Holdee holdee) {
			this.valueHoldee = holdee;
		}
		public Holdee getReferenceHoldee() {
			return referenceHoldee;
		}
		public void setReferenceHoldee(Holdee referenceHoldee) {
			this.referenceHoldee = referenceHoldee;
		}
	}
	
	public static class ParallelConfinedBreaker {
		
		// sets contract in the first thread, break contract in the second thread
		public void breakValueHoldeeInCalleeThread() throws InterruptedException {
			final ConfinedHolder ch = new ConfinedHolder();
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					ch.getValueHoldee().setValue(3);
				}
			}).start();
		}
		
		public void breakValueHoldeeInCalleerThread() throws InterruptedException {
			class BreakingThread extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
				}
				public ConfinedHolder getCh() {
					return ch;
				}					
			}
			BreakingThread bth = new BreakingThread();
			bth.start();
			bth.join();
			bth.getCh().getValueHoldee().setValue(7);
		}
		
		public void breakContractBetweenTwoParallelThreads() {
			class ParallelHolder extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				public ConfinedHolder getCh() {
					return ch;
				}
			};
			class ParallelBreaker extends Thread {
				ParallelHolder ph;

				public ParallelBreaker(ParallelHolder ph) {
					super();
					this.ph = ph;
				}
				public void run() {
					ph.getCh().getValueHoldee().setValue(2);
				}
			};
			ParallelHolder ph = new ParallelHolder();
			ph.start();
			new ParallelBreaker(ph).start();
		}

		public void changeReferenceBetweenTwoParallelThreads() {
			class ParallelHolder extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				public ConfinedHolder getCh() {
					return ch;
				}
			};
			class ParallelBreaker extends Thread {
				ParallelHolder ph;

				public ParallelBreaker(ParallelHolder ph) {
					super();
					this.ph = ph;
				}
				public void run() {
					ph.getCh().setReferenceHoldee(new Holdee());
				}
			};
			ParallelHolder ph = new ParallelHolder();
			ph.start();
			new ParallelBreaker(ph).start();			
		}
	}
	
	public static class ParallelConfinedLegal {
		// sets contract in the first thread, break contract in the second thread
		public void setValueHoldeeInCalleeThread() throws InterruptedException {
			final ConfinedHolder ch = new ConfinedHolder();
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					ch.getValueHoldee().setValue(3);
				}
			}).start();
		}	
		
		public void setValueHoldeeInCalleerThread() throws InterruptedException {
			class BreakingThread extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
				}
				public ConfinedHolder getCh() {
					return ch;
				}					
			}
			BreakingThread bth = new BreakingThread();
			bth.start();
			bth.join();
			bth.getCh().getValueHoldee().setValue(7);
		}	
		public void breakContractBetweenTwoParallelThreads() {
			final Object lock = new Object();
			class ParallelHolder extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
					synchronized (lock) {
						lock.notify();
					}
				}
				public ConfinedHolder getCh() {
					return this.ch;
				}
			};
			class ParallelBreaker extends Thread {
				ParallelHolder ph;

				public ParallelBreaker(ParallelHolder ph) {
					super();
					this.ph = ph;
				}
				public void run() {
					synchronized (lock) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					ph.getCh().getValueHoldee().setValue(2);
				}
			};
			ParallelHolder ph = new ParallelHolder();
			ph.start();
			new ParallelBreaker(ph).start();
		}

		public void changeReferenceBetweenTwoParallelThreads() {
			final Object lock = new Object();
			class ParallelHolder extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
					synchronized (lock) {
						lock.notify();
					}
				}
				public ConfinedHolder getCh() {
					return this.ch;
				}
			};
			class ParallelBreaker extends Thread {
				ParallelHolder ph;

				public ParallelBreaker(ParallelHolder ph) {
					super();
					this.ph = ph;
				}
				public void run() {
					synchronized (lock) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					ph.getCh().setReferenceHoldee(new Holdee());
				}
			};
			ParallelHolder ph = new ParallelHolder();
			ph.start();
			new ParallelBreaker(ph).start();			
		}

		public void changeNotConfinedReference() {
			final Object lock = new Object();
			class ParallelHolder extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
					synchronized (lock) {
						lock.notify();
					}
				}
				public ConfinedHolder getCh() {
					return this.ch;
				}
			};
			class ParallelBreaker extends Thread {
				ParallelHolder ph;

				public ParallelBreaker(ParallelHolder ph) {
					super();
					this.ph = ph;
				}
				public void run() {
					synchronized (lock) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					ph.getCh().setValueHoldee(new Holdee());
				}
			};
			ParallelHolder ph = new ParallelHolder();
			ph.start();
			new ParallelBreaker(ph).start();					
		}

		public void changeNotConfinedValue() {
			final Object lock = new Object();
			class ParallelHolder extends Thread {
				ConfinedHolder ch;
				@Override
				public void run() {
					ch = new ConfinedHolder();
					synchronized (lock) {
						lock.notify();
					}
				}
				public ConfinedHolder getCh() {
					return this.ch;
				}
			};
			class ParallelBreaker extends Thread {
				ParallelHolder ph;

				public ParallelBreaker(ParallelHolder ph) {
					super();
					this.ph = ph;
				}
				public void run() {
					synchronized (lock) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					ph.getCh().getReferenceHoldee().value = 3;
				}
			};
			ParallelHolder ph = new ParallelHolder();
			ph.start();
			new ParallelBreaker(ph).start();			
		}	
	}

	@Test
	public void breakValueHoldeeInCalleeThread_NOT_OK() throws InterruptedException {
		if (verifyAssertionError(JPF_ARGS)) {
			new ParallelConfinedBreaker().breakValueHoldeeInCalleeThread();
		}
	}
	@Test
	public void setValueHoldeeInCalleeThread_OK() throws InterruptedException {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ParallelConfinedLegal().setValueHoldeeInCalleeThread();
		}
	}
	
	@Test
	public void breakValueHoldeeInCalleerThread_NOT_OK() throws InterruptedException {
		if (verifyAssertionError(JPF_ARGS)) {
			new ParallelConfinedBreaker().breakValueHoldeeInCalleerThread();
		}
	}
	
	@Test
	public void setValueHoldeeInCalleerThread_OK() throws InterruptedException {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ParallelConfinedLegal().setValueHoldeeInCalleerThread();
		}
	}

	@Test
	public void breakContractBetweenTwoParallelThreads_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			new ParallelConfinedBreaker().breakContractBetweenTwoParallelThreads();
		}
	}
	@Test
	public void setContractBetweenTwoParallelThreads_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ParallelConfinedLegal().breakContractBetweenTwoParallelThreads();
		}
	}
	@Test
	public void changeReferenceBetweenTwoParallelThreads_NOT_OK() {
		if (verifyAssertionError(JPF_ARGS)) {
			new ParallelConfinedBreaker().changeReferenceBetweenTwoParallelThreads();
		}
	}
	@Test
	public void changeReferenceBetweenTwoParallelThreads_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ParallelConfinedLegal().changeReferenceBetweenTwoParallelThreads();
		}
	}	
	@Test
	public void changeNotConfinedReference_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ParallelConfinedLegal().changeNotConfinedReference();
		}
	}
	@Test
	public void changeNotConfinedValue_OK() {
		if (verifyNoPropertyViolation(JPF_ARGS)) {
			new ParallelConfinedLegal().changeNotConfinedValue();
		}
	}	
}
