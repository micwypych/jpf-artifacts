package gov.nasa.jpf.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Specifies that annotated field is confined to the scope provided in
 * the to parameter of this annotation. 
 */
@Target({FIELD})
@Retention(RUNTIME)
@Inherited
@Documented
public @interface ConfinedField {

	/**
	 * <p>Specifies the confinement scope. The scope may be specified
	 * with the following syntax</p>
	 * <p><ul>
	 * 	<li>&#35;regioName</li>
	 * 	<li>canonical className</li>
	 * 	<li>canonical packageName.*</li>
	 * </ul></p>
	 * <p>Both, regions and classes may not widen scope specified in this
	 * annotation</p>
	 * <p>When, both, super class and enclosing class are confined, annotated
	 * field can not widen intersection of super class confined scope
	 * and enclosing class confined scope</p>
	 * @return
	 */
	String[] to() default {""};
	
	/**
	 * Specifies that this reference may not be changed by
	 * objects not specified in the <b>to</b> parameter. 
	 * 
	 * @return
	 */
	boolean reference() default true;
	
	/**
	 * Specifies that the values of this object may not be 
	 * changed by objects not specified in the <b>to</b> 
	 * parameter.  
	 * 
	 * @return
	 */
	boolean value() default true;
}
