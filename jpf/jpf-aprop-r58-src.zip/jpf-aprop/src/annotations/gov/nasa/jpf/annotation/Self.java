package gov.nasa.jpf.annotation;

import static java.lang.annotation.ElementType.FIELD;

import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Self is a reference constraint specifying that the
 * reference may not leak to objects different than
 * object's owner.  
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({FIELD})
@Documented
@Inherited
public @interface Self {

	/**
	 * Specifies that the reference may be changed only
	 * by the owner's object. 
	 * 
	 * @return
	 */
	boolean reference() default true;
	
	/**
	 * Specifies that the referenced value may be changed
	 * only by the owner's object. 
	 * 
	 * @return
	 */
	boolean value() default true;
	
}
