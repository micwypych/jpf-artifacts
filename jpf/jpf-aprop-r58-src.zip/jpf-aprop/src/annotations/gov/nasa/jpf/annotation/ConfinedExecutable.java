package gov.nasa.jpf.annotation;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Specifies that annotated method is confined to scope provided in
 * annotation value.
 * 
 * Scope may be specified using the following syntax:
 * 	- &#35;regioName
 * 	- ? extends canonical className
 * 	- canonical className
 * 	- canonical packageName.*
 *
 * Regions and classes specified in the annotation value can not widen confined scope
 * specified in type annotation.
 * 
 * In case both, super class and enclosing class are confined, annotated method can not
 * widen intersection of super class confined scope and enclosing class confined scope.
 */
@Target({METHOD, CONSTRUCTOR})
@Retention(RUNTIME)
@Inherited
@Documented
public @interface ConfinedExecutable {

	String[] value() default {""};
	
}
