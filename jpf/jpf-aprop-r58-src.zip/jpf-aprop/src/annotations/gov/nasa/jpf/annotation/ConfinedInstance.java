package gov.nasa.jpf.annotation;

/**
 * Specifies that the annotated construct may be accessed only within
 * 
 */
public @interface ConfinedInstance {

}
