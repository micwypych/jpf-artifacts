package gov.nasa.jpf.annotation;

import static java.lang.annotation.ElementType.PACKAGE;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Specifies that annotated type or package
 * belong to region with specified value.
 * 
 */
@Target({TYPE, PACKAGE})
@Retention(RUNTIME)
@Documented
public @interface Region {
	
	public static final String REGION_PREFIX = "#";
	
	String[] value() default "";
	
}
