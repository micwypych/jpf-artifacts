package gov.nasa.jpf.annotation;

/**
 * <p>Specifies that annotated constructor is confined to the scope provided in
 * the annotation's value.</p>
 * 
 * <p>Confinement scope may be specified using the following syntax:
 * <ul>
 * 	<li>&#35;regioName</li>
 * 	<li>? extends canonical className</li>
 * 	<li>canonical className</li>
 * 	<li>canonical packageName.*</li>
 * </ul>
 * </p>
 * <p>Regions and classes specified in the annotation's value can not widen the confined scope
 * specified in the type's annotation.</p>
 * 
 * <p>Both super class and enclosing class are confined, annotated constructor 
 * can not widen intersection of super class confined scope and enclosing 
 * class confined scope.
 * </p>
 * 
 * @author Filip Rogaczewski
 */
@Deprecated
public @interface ConfinedConstructor {

	String[] value() default {""};
}
