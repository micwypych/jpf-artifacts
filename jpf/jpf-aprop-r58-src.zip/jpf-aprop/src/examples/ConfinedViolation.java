import gov.nasa.jpf.annotation.ConfinedField;

public class ConfinedViolation {

	public static void main(String... args) {
		new TakeoffCalculator().calculateTakeoff();	
	}

}

class Temperature {
	double degrees;

	public Temperature(double d) {
		this.degrees = d;
	}

	public double getDegrees() {
		return degrees;
	}

	public void setDegrees(double degrees) {
		this.degrees = degrees;
	}	
}

class AirDensity {
	@ConfinedField(reference = true, value = true, to = {"gov.nasa.jpf.test.aprop.region.AirDensity", "gov.nasa.jpf.test.aprop.region.AircraftSensors"})
    private Temperature airTemperature;
    public AirDensity(Temperature temperature) {
    	this.airTemperature = temperature;
	}
	public Temperature getAirTemperature() {
        return airTemperature;
    }
}
class TakeoffCalculator {
	AircraftDataFacade aircraftDataFacade = new AircraftDataFacade();
    public void calculateTakeoff() {
        AirDensity ad = aircraftDataFacade.getAirDensity();
    }
}

class AircraftSensors {
	static AirDensity getAirDensity() {
		return new AirDensity(new Temperature(2.0d));
	}
}

class AircraftDataFacade {
    public AirDensity getAirDensity() {
        AirDensity ad = AircraftSensors.getAirDensity();
        ad.getAirTemperature();
        return ad;
    }
}
